#include <iostream> // input output stream
#include "BinarySearchTree.h" // Insert a copy of the BinarySearchTree.h file into this cpp file
#include "BinarySearchTreeV1.0.h" // Insert a copy of the BinarySearchTreeV1.0.h file into this cpp file

using namespace std;

/* Input data stream: 50, 80, 90, 30, 60, 40, 10, 85, 45

		   50
		 /    \
	   30      80
	  /  \     /  \
	10   40   60   90
		   \      /
		   45    85

*/

int main() 
{
	// Initiate and create a Binary Search Tree as myBinarySearchTree
	BinarySearchTree<double> myBinarySearchTree = BinarySearchTree<double>();

	// TESTING GROUND 
	// Insert into Binary Search Tree using recursive function
	// These number by default will be stored in the Binary Search Tree
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 50);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 80);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 90);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 30);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 60);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 40);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 10);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 85);
	myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 45);
	//myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, 33);
	//myBinarySearchTree.root = myBinarySearchTree.deleteNode(myBinarySearchTree.root, 45);

	// display Binary Search Tree using preorder traversal
	myBinarySearchTree.preorder(myBinarySearchTree.root);
	cout << endl;

	//
	//Node* myNode = myBinarySearchTree.findMax(myBinarySearchTree.root);
	//cout << "Max = " << myNode->key << endl;

	//
	//Node* myNode2 = myBinarySearchTree.findMin(myBinarySearchTree.root);
	//cout << "Min = " << myNode2->key << endl;

	// END  OF TESTING GROUND

	// An int value to collect user input on what number they insert or delete
	int inputInt;
	// An int value that will collect user iput on what function they want to interact with
	int choice = 99;

	// A do while loop which will process everything for user interaction until user input's 99 as their choice
	do 
	{
		// Cout statemente informing the user about the Binary Search Tree menu
		cout << "\nMenu to Binary Search Tree:\n";
		// Inform user if they wish to insert a number into the Binary Search Tree type 1
		cout << "1: To insert an integer on the Binary Search Tree\n";
		// Inform user if they wish to delete a number from the Binary Search Tree type 2
		cout << "2: To delete an integer from the Binary Search Tree\n";
		// Inform user if they wish to find the largest value in the Binary Search Tree type 3
		cout << "3: To find the maximum integer on the Binary Search Tree\n";
		// Inform user if they wish to find the smallest value in the Binary Saerch Tree type 4
		cout << "4: To find the minimum integer on the Binary Search Tree\n";
		// Inform user if they wish to display the Binary Search Tree in preorder traversal press 5
		cout << "5: To display the Binary Search Tree in preorder traversal\n";
		// Inform user if they wish to display the Binary Search Tree in inorder traversal press 6
		cout << "6: To display the Binary Search Tree in inorder traversal\n";
		// Inform user if they wish to display the Binary Search Tree in postorder traversal press 7
		cout << "7: To display the Binary Search Tree in postorder traversal\n";
		// Inform user if they can to stop the program type 99
		cout << "99: Exit\n";

		// Asking the user to input a number for the menu
		cout << "Please enter your choice (#): ";
		// Collec the number they inputted in the menu
		cin >> choice;

		// A switch statement that will execute each function depending on choice integer from user
		switch (choice) 
		{
			// Execute the insert node function if user typed 1
			case 1:
				// Ask user what number they want to insert in the Binary search Tree
				cout << "Enter an integer to insert: ";
				// Collect the number they inputted to insert
				cin >> inputInt;
				// Execute the insert node function with the user's number 
				myBinarySearchTree.root = myBinarySearchTree.insertNode(myBinarySearchTree.root, inputInt);
				cout << endl;
				// Jump out of loop
				break;
			// Execute the delete node function if user typed 2
			case 2:
				// Ask user what number they want to delete in the Binary Search Tree
				cout << "Enter an integer to delete: ";
				// Collect the number they inputted to insert
				cin >> inputInt;
				// Execute the delete node function with the user's number 
				myBinarySearchTree.root = myBinarySearchTree.deleteNode(myBinarySearchTree.root, inputInt);
				// Jump out of loop
				break;
			// Execute the find max function if user typed 3
			case 3:
				{
					// Find the largest value in the Binary Search Tree
					Node <double>* myNode = myBinarySearchTree.findMax(myBinarySearchTree.root);
					// Display the largest number in the Binary Search Tree to user
					cout << "Max = " << myNode->key << endl;
				}
				// Jump out of loop
				break;
			// Execute the find min function if user typed 4
			case 4:
				{
					// Find the smallest value in the Binary Search Tree
					Node <double>* myNode2 = myBinarySearchTree.findMin(myBinarySearchTree.root);
					// Display the smallest number in the Binary Search Tree to user
					cout << "Min = " << myNode2->key << endl;
				}
				// Jump out of loop
				break;
			// Execute the preorder function if user typed 5
			case 5:
				{
					// Display the Binary Search tree in preorder traversal
					myBinarySearchTree.preorder(myBinarySearchTree.root);
					cout << endl;
				}
				// Jump out of loop
				break;
			// Execute the inorder function if user typed 6
			case 6:
				{
					// Display the Binary Search tree in inorder traversal
					myBinarySearchTree.inorder(myBinarySearchTree.root);
					cout << endl;
				}
				// Jump out of loop
				break;
			// Execute the postorder function if user typed 7
			case 7:
				{
					// Display the Binary Search tree in postorder traversal
					myBinarySearchTree.postorder(myBinarySearchTree.root);
					cout << endl;
				}
				// Jump out of loop
				break;
		}
	} while (choice != 99); // A while loop that will keep the menu running until user types 99

	// Return the number zero as an exit code to show that the program ran through fully with no problems.
	return 0;
}	