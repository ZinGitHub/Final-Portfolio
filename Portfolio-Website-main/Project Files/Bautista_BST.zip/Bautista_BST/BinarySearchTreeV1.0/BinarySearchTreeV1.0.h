#ifndef BINARY_SEARCH_TREE_FUNC_H
#define BINARY_SEARCH_TREE_FUNC_H
#include<iostream> // Input output stream
#include "BinarySearchTree.h" // Include the prototpyes within the node and Binary Search Tree class

using namespace std;

// Template declared
template <class T>
// Function definition for getNode
// Create a new node
Node <T>* BinarySearchTree<T>::getNode(T val)
{
	// Node pointing to the new node
	Node <T> * newNode;
	// Initialize and create the new node
	newNode = new Node <T>();
	// Create the node by filling in the key as the value
	newNode->key = val;
	// Setting the left node as NULL
	newNode->left = NULL;
	// Setting the right node as NULL
	newNode->right = NULL;
	// Return the data of newNode
	return newNode;
}

// Template declared
template <class T>
// Function definition for insertNode
// Insert a new node into Binary Search Tree - Recursive function
Node <T>* BinarySearchTree<T>::insertNode(Node <T>* root, T val)
{
	// Stop when Null node is reached
	if (root == NULL) 
	{
		// Return the value of getNode
		return getNode(val);
	}

	// Traverse right node if input value is greater than key
	if (root->key < val)
	{
		// Insert the new node to the right side
		root->right = insertNode(root->right, val);
	}

	// Traverse left node if input value is less than the key
	if (root->key > val) 
	{
		// Insert the new node to the left side
		root->left = insertNode(root->left, val);
	}

	// Return the root data
	return root;
}

// Template declared
template <class T>
// Function definition for findMax
// Find the maximum value in the Binary Search Tree
Node <T>* BinarySearchTree<T>::findMax(Node <T>* root)
{
	// Stop when Null node is reached 
	if (root == nullptr) 
	{
		// Return the root data
		return root;
	}

	// While loop that will contiue going to the right side of the Binary Search Tree until there is no more nodes
	while (root->right != nullptr)
	{
		// Set the root to the farthest side of the right side of the Binary Search Tree
		root = root->right;
	}

	// Return the root data
	return root;
}

// Template declared
template <class T>
// Function defintion for findMin
// find the smallest value in the Binary Search Tree
Node<T>* BinarySearchTree<T>::findMin(Node<T>* root)
{
	// Stop when Null node is reached
	if (root == nullptr) 
	{
		// Return the root data
		return root;
	}

	// While loop that will contiue going to the left side of the Binary Search Tree until there is no more nodes
	while (root->left != nullptr)
	{
		// Set the root to the farthest side of the left side of the Binary Search Tree
		root = root->left;
	}

	// Return the root data
	return root;
}

// Template declared
template <class T>
// Function definition for deleteNode
// Delete a node in the Binary Search Tree - Recursive Function
Node<T>* BinarySearchTree<T>::deleteNode(Node <T>* root, T val)
{
	// Deleting a node should be applicable for the 3 cases
	// Deleting a node with no children
	// Deleting a node with one child
	// Deleting a node with two children 

	// Stop when Null node is reached
	if (root == NULL) 
	{
		// Return the value of getNode
		return getNode(val);
	}

	// Traverse left node if input value is less than the key
	if (root->key > val) 
	{
		// Delete the node from the left side
		root->left = deleteNode(root->left, val);
	}
	// Traverse right node if input value is greater than key
	else if (root->key < val)
	{
		// Delete the node from the right side
		root->right = deleteNode(root->right, val);
	}
	// An else statement incase the conditions above are not followed
	else 
	{
		// If statement in case the left side of node is NULL
		if (root->left == NULL)
		{
			// Create a temporary node pointing to the right side
			Node<T> * temp = root->right;
			// free() function used to deallocate a block of memory previously allocated and making it avialable for further allocations for root
			free(root);
			// Return the data of temp node
			return temp;
		}
		// In case the right side of node is NULL
		else if (root->right == NULL)
		{
			// Create a temporary node pointing to the left side
			Node<T>* temp = root->left;
			// free() function used to deallocate a block of memory previously allocated and making it avialable for further allocations for root
			free(root);
			// Return the data of temp node
			return temp;
		}

		// Create a temporary node by finding the smallest value on the right side
		Node<T> * temp = findMin(root->right);
		// Set the key within the root and temp equal to each other
		root->key = temp->key;
		// Delete the root on the right side and temp key
		root->right = deleteNode(root->right, temp->key);
	}

	// Return root data
	return root;

}

// Template declared
template <class T>
// Preorder traversal - root, left, right
// Function defintion for preorder - recursive function
void BinarySearchTree<T>::preorder(Node <T>* root)
{
	// Stop when Null node is reached
	if (root == NULL) 
	{
		// Exit the statement
		return;
	}

	// Display the nodes accordingly to preorder
	cout << root->key << " ";

	// Process left node
	preorder(root->left);

	// Process right node
	preorder(root->right);
}

// Template declared
template <class T>
// Inorder traversal - left, root, right
// Function defintion for inorder - recursive function
void BinarySearchTree<T>::inorder(Node <T>* root)
{
	// Stop when Null node is reached
	if (root == NULL)
	{
		// Exit the statement
		return;
	}

	// Process left node
	inorder(root->left);

	// Display the nodes accordingly to inorder
	cout << root->key << " ";
	
	// Process right node
	inorder(root->right);
}

// Template declared
template <class T>
// Postorder traversal - left, right, root
// Function definition for postorder
void BinarySearchTree<T>::postorder(Node <T> * root)
{
	// Stop when Null node is reached
	if (root == NULL)
	{
		// Exit the statement
		return;
	}

	// Process left node
	postorder(root->left);

	// Process right node
	postorder(root->right);

	// Display the nodes accordingly to postorder
	cout << root->key << " ";
}

#endif
