#ifndef BINARY_SEARCH_TREE_H
#define BINARY_SEARCH_TREE_H
#include<iostream> // Input output stream

// Definition for the Node in the Binary Search Tree
// template declared
template <class T>
// Data Structure for each node (leaf) in the tree
// Class for the Nodes in the Binary Search Tree
class Node {
	// Public access specifier
	// All attributes will be placed into public access
	public:
		// Int value storing the key for each node
		int key;
		// A pointer referencing the left side of the Binary Search Tree
		Node* left;
		// A pointer referencing the right side of the Binary Search Tree
		Node* right;
};

// Definition for the Binary Search Tree
// Template declared.
template <class T>
// Binary Search Tree starts with root node
// Class for the Binary Search Tree
class BinarySearchTree {
	// Public access specifier
	// Everything except the getNode will be placed into public access
	public:
		// The beginning of the Binary Search Tree
		// Point to the first node in the Binary Search Tree
		Node <T>* root;

		// Constructor for the Binary Search Tree
		BinarySearchTree() 
		{
			// Initialize the root node as NULL
			root = NULL;
		}
		// Node pointing to the inserted node via the user and test numbers
		// Setting the root node and val(value) as the parameters
		// Recursive function prototype for insertNode
		Node <T> * insertNode(Node <T>* root, T val); 
		// Function prototype for preorder
		// This function will organize the Binary Search Tree via the preorder method (root, left, right)
		// Recursive function prototype for preorder
		void preorder(Node <T>* root); // Display using preorder traversal
		// Function prototype for inorder
		// This function will organize the Binary Search Tree via the inorder method (left, root, right)
		// Recursive function prototype for inorder
		void inorder(Node <T>* root);
		// Function prototype for postorder
		// This functio will organize the Binary Search Tree via the postorder method (left, right, root)
		// Recursive function prototype for postorder
		void postorder(Node <T>* root);
		// Node pointing to the deleted node via the user
		// Setting the root node and val(value) as the parameters
		// Recursive function prototype for delteNode
		Node <T>* deleteNode(Node <T>* root, T val);
		// Node pointing to the node that has the highest value
		// Setting the root node as a parameter
		// Function prototype for findMax
		Node <T>* findMax(Node <T>* root);
		// Node pointinf to the node that has the lowest value
		// Setting the root node as a parameter 
		// Function prototype for findMin
		Node <T>* findMin(Node <T>* root);
	private:
		// Private access specifier
		// Node pointing to the created or deleted node
		// Setting the val(value) as a parameter
		// Function prototype for getNode
		// Create a new node to insert new data
		Node <T>* getNode(T val);
};

#endif // BINARY_SEARCH_TREE_H