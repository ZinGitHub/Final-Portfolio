#include <iostream> // input output stream
#include "LinkedList.h" // Insert a copy of the LinkedList.h file into this cpp file
#include "DoubleLinkedListTemplate.h" // Insert a copy of the DoubleLinkedListTemplate.h file into this cpp file


int main()
{
	// Setting the head of the Node as null to make the list empty initially.
	Node <double> * head = NULL;

	// Initiate an integer with the double Linked List.
	LList<double> myList = LList<double>();

	// These numbers will by default be stored in the double linked list.
	// This is used for testing purposes. Specifically to see if the insertNode function works
	// Beginning of testing 
	myList.insertNode(11); // This is the first element in the double linked list.
	myList.insertNode(22); // 2nd element.
	myList.insertNode(33); // 3rd element.
	myList.insertNode(44); // 4th elment.
	myList.insertNode(55); // 5th element.
	myList.insertNode(66); // 6th element
	myList.insertNode(77); // 7th element.
	myList.insertNode(88); // This is the latest element in the double linked list until user adds more.
	// End of testing 

	// Display the the double linked list with the testing elements.
	myList.displayList();

	// This is used for testing purposes. Specifically to if the programm is able to find specific data numbers.
	// Beginning of testing 
	// If the findNode function detects the number 22 in the double linked list then output the statement "Data found."
	// This if statment by default should be executed
	if (myList.findNode(22) != nullptr)
	{
		// Output "Data found." if codition is met.
		std::cout << "Data found." << std::endl;
	}
	// An else statement that will execute in case the findNode function does not finde the number 22 in the double linked list.
	// By deafult this statement should be executed unless configured to do so.
	else
	{
		// Output "Data not found."  if condition is met.
		std::cout << "Data not found." << std::endl;
	}

	// An if statement that will execute if the findNode function detects the number 100 in the doublde linked list then output the statement "Data found."
	// This if statement by default should not be executed unless configured to do so.
	if (myList.findNode(100) != nullptr)
	{
		// Output "Data found." if codition is met.
		std::cout << "Data found." << std::endl;
	}
	// An else statement that will execute a cout statement if findNode does not find 100 in the double lined list.
	// This else statement should be executed by default.
	else
	{
		// Output "Data not found."  if condition is met.
		std::cout << "Data not found." << std::endl;
	}
	// End of testing

	// Add a pause once all the testing has been completed.
	system("pause");

	// An int value to collect user input on what number they want to insert, delete, or view in the double linked list.
	int inputInt;
	// An int value that will collect user input on what function they want to interact with.
	// User input's 1 = user will insert a number into the double linked list.
	// User input's 2 = user wants to see if there is a specific number in the double linked list.
	// User input's 3 = user wants to see the numbers in the double linked list and how many their are.
	// User input's 4 = user wants to delete a number in the double linked list.
	// User input's 5 = user wants to see the double linked list but in reverse order.
	// User input's 99 = user wants to exit out of the program.
	int choice = 99;

	// A do loop which will process everything within its code block than check if user inputted 99 as choice.
	do
	{
		// Cout statement informing the user about the double linked list menu.
		std::cout << "\nMenu to Double Linked List:\n";
		// Cout statement to inform the user that they can type 1 to insert a number into the double linked list.
		std::cout << "1: To insert an integer on List\n";
		// Cout statement to inform the user that they can type 2 if they want to see if there is a specific number in the double linked list.
		std::cout << "2: To find a specific node\n";
		// Cout statement to inform the user that they can type 3 if they want to see the numbers in the double linked list, and how many.
		std::cout << "3: To display list\n";
		// Cout statement to inform the user that they can type 4 if they want to delete a number in the double linked list.
		std::cout << "4: To delete an integer on list\n";
		// Cout statement to inform the user that they can type 5 if they want to view the double linked list but in reverse.
		std::cout << "5: To Reverse the list\n";
		// Cout statement to inform the user that they can type 99 if they want to exit and close the program.
		std::cout << "99: Exit\n";

		// Cout statement asking the user to input a number.
		std::cout << "Please enter your choice (#): ";
		// Cin to collect the number the user inputted and store it into the int choice variable.
		std::cin >> choice;

		// A switch code block that will execute certain blocks of code depending on what the user enters //
		switch (choice)
		{
		// If the user inputs 1 then prepare to execute the insertNode function.
		case 1:
			// A cout statement asking the user to enter a integer.
			std::cout << "Enter an integer: ";
			// Collect the number the user inputted.
			std::cin >> inputInt;
			// Once the inputInt collected the user input theb execute the insertNode function into myList with the number stored in inputInt.
			myList.insertNode(inputInt);
			// Jump out of the loop.
			break;
		// If the user inputs 2 then prepare to execute the findNode function.
		case 2:
			// A cout statement asking the user to enter a integer they want to find in the double linked list.
			std::cout << "Enter the integer to be found: ";
			// Collect the number the user inputted.
			std::cin >> inputInt;
			{
				// Execute the findNode function with the int inputInt variable. 
				// Set the Node pointer to the value of inputInt.
				Node <double> * nPtr = myList.findNode(inputInt);

				// An if/else statement that will check if the number the user inputted is in the double linked list.
				// The if statement has a condition to check if the Node pointer is not a null pointer.
				if (nPtr != nullptr)
				{
					// Cout statement that will inform the user that the number they inputted has been found in the double linked list.
					// nPtr->data = the number found in the double linked list.
					std::cout << "Found data: " << nPtr->data << std::endl;
				}
				// An else statement that will execute due to the findNode function not finding the number requested by user.
				else
				{
					// Cout statement to inform the user that the number they requested to search has not been found.
					std::cout << "Data not found." << std::endl;
				}
			}
			// Jump out of the loop.
			break;
		// If the user inputs 3 then prepare to execute the displayNode function.
		case 3:
			// Execute the displayList function
			myList.displayList();
			// Jump out of the loop.
			break;
		// If the user inputs 4 prepare to then execute the deleteNode function.
		case 4:
			// An int varaiable that will store user input on what position they would like to.
			int n;
			// A cout statement asking the user to input the position that they want which will delete the number in that position.
			std::cout << "Enter a position: ";
			// Collect user input.
			// %d =  placeholder for the integer
			// &n = Get the memory adress of the n variable.
			scanf_s("%d", &n);
			// Execute the deleteNode function.
			// n = the position, in which whatever number is at that position will be deleted.
			myList.deleteNode(n);
			// Jump out of the loop.
			break;
		// If the user inputs 5 prepare to then execute the displayReverse function.
		case 5:
			// Execute the displayReverse function.
			// This function does not like it if you deleted numbers beforehand unless you replace them first.
			myList.displayReverse();
			// Jump out of the loop.
			break;
		}
	} while (choice != 99); // A while loop which will stop the program functionality once user types 99 in the menu.

	// Once the user types 99 to exit and close the program a cout statement will inform the user that the program is closing.
	std::cout << "Ending Program...\n";
	// Pause the program for the user to completly shut down the program.
	system("pause");
	// return the number zer as an exit code to show that the program ran through fully with no problems.
	return 0;
}