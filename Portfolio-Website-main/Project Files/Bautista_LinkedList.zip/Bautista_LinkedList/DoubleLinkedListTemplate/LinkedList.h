#ifndef LINKED_LIST_H 
#define LINKED_LIST_H 

// Definition for the Node in the double linked list.
// Template declared.
template <class T>
// Class for the Nodes in the double linked list.
class Node
{
	// Public access specifier.
	// All attributes will be placed into public access.
	public:
		// The data stored in the Node.
		int data;
		// A pointer reference for the next Node.
		Node* nextPtr;
		// A pointer reference for the previous Node.
		Node* prevPtr;
		// The constructor for Node.
		Node(T newData)
		{
			// Set the data to newData local variable.
			data = newData;
			// Intialize the next pointer as a null pointer.
			nextPtr = nullptr;
			// Intialize the previous pointer as a null pointer.
			prevPtr = nullptr;
		}
	// private access specifier.
	private:
};

// Definition for the double linked list.
// Template declared.
template <class T>
// Class for the double LList (linked list).
class LList
{
	// Public access specifier.
	// All attributes will be placed into public access.
	public:
		// The beginning of the double linked list.
		// Points to the first node of double linked list.
		struct Node <T> * head;
	
		// The llSize integer variable will count how many numbers are present within the double linked list
		// This variable will be used for the insertNode and deleteNode functions.
		int llSize;

		// Constructor for double LList (linked list).
		LList()
		{
			// Initialize the head as a null pointer.
			head = nullptr;
			// Start the int value of llSize as zero until the program collects numbers/nodes.
			llSize = 0;
		}

		// Returns a pointer to the Node whose key will match to dataToFind.
		Node <T> * findNode(T dataToFind);

		// Definition for the insertNode function.
		// This function will allow users to insert a number into the double linked list.
		void insertNode(T newData);
		// Definition for the deleteNode function.
		// This function will allow users to delete a number from the double linked list.
		void deleteNode(T delNode);
		// Definition for the displayList function.
		// This function will allow users to view the data on the double linked list.
		void displayList();
		// Definition for the displayReverse function.
		// This function will allow users to view the data backwards on the double linked list
		// This function is to give visual evidence that a double linked list is present.
		void displayReverse();

		// This will take the integer in newData and create a node.
		struct Node <T> * getNewNode(T newData) 
		{
			// Using malloc to create a Node in heap memory by reserving memory in heap.
			struct Node <T> * newNode = (struct Node <T> *)malloc(sizeof(struct Node <T>));
			// Create the Node by filling in the data field as newData.
			newNode->data = newData;
			// Setting previous pointer as NULL.
			newNode->prevPtr = NULL;
			// Settign next Pointer as NULL.
			newNode->nextPtr = NULL;
			// Return a pointer to the Node
			return newNode;
		}
	// private access specifier.
	private:
};

#endif
