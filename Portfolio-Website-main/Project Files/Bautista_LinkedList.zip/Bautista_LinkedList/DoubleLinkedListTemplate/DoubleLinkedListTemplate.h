#ifndef LINKED_LIST_FUNC_H 
#define LINKED_LIST_FUNC_H 
#include <iostream> // input output stream.
#include "LinkedList.h" // Include the definition of Node and LList.

// Returns a pointer in which it'll match to dataToFind.
// Template declared.
template <class T>
// Function prototype for findNode. 
Node <T> * LList<T>::findNode(T dataToFind)
{
	// Node pointer that points to the head.
	Node <T> * nPtr = head;

	// A while loop that will run a code block.
	// If the Node pointer does not equal null pointer.
	// And the Node pointer is accessing the data.
	// And does not equal dataToFind.
	while (nPtr != nullptr && nPtr->data != dataToFind)
	{
		// Traverse forward with Node pointer and next pointer.
		// Keeep going until findNode detects the right number.
		// Node pointer accesses next pointer.
		nPtr = nPtr->nextPtr;
	}
	// Return the value of the Node pointer.
	// Exit.
	return nPtr;
}

// Inserts a new Node at the end of the list which will equal to newData.
// Template declared.
template <class T>
// Function prototype for insertNode.
void LList<T>::insertNode(T newData)
{
	// Call the function getNewNode and pass it through newData.
	// the getNewNode will return a pointer to the newly created Node that will be recieved in newData variable.
	struct Node <T> * newNode = getNewNode(newData);
	// An if statement if the head is equal to NULL due to empty list.
	if (head == NULL)
	{
		// Set head as the address of new Node.
		head = newNode;
		// Exit the if statement.
		return;
	}
	
	// Inserting a Node when list is now empty. 
	// Once the new Node is created, set the previous field of existing head Node as the address of the new Node.
	// Head accessing previous pointer.
	head->prevPtr = newNode;
	// Set the next field of new Node as the address of the current head+
	// new Node accessing next pointer.
	newNode->nextPtr = head;
	// Set head as address of new Node.
	head = newNode;
	// Increment the value size of the double linked list by 1.
	llSize++;
}

// Delete a Node depending on the position decided by user and will equal to delNode.
// Template declared.
template <class T>
// Function prototype for deleteNode.
void LList<T>::deleteNode(T delNode)
{
	// Decrment the value of the size of the double linked list by 1.
	llSize--;
	// Temporary variable that points to Node and points to the head.
	struct Node <T> * temp1 = head;
	// if statement to delete the head Node
	if (delNode == 1)
	{
		// The head will now point to the second Node.
		// temp1 accessing next pointer.
		head = temp1->nextPtr;
		// Deallocate the memory in temp1.
		delete(temp1);
		// Exit the if statement.
		return;
	}

	// integer variable storing i.
	int i;

	// Loop to get to the (delNode-1)th Node
	for (i = 0; i < delNode - 2; i++)
	{
		// Temporary variable pointing to next pointer.
		// temp1 points to (delNode-1) Node
		// temp1 accessing next pointer.
		temp1 = temp1->nextPtr;
	}

	// Temporary variable to point to the (delNode)th Node.
	// 2nd temporary varible is equal to what temp1 accesses from bext pointer.
	struct Node <T> * temp2 = temp1->nextPtr;
	// (delNode+1)th Node
	// Both temp1 and temp2 have access to next pointer, and equal each other.
	temp1->nextPtr = temp2->nextPtr;
	// Deallocate the memory in temp2.
	delete(temp2);
}

// Display all Nodes in the list.
// Template declared.
template <class T>
// Function prototype for displayList.
void LList<T>::displayList()
{
	// Node pointer.
	Node <T> * nPtr;

	// An if/else statement that will check if the double linked list has data in the head.
	// Display the double linked list if the head is not a null pointer.
	if (head != nullptr)
	{
		// A cout statement informing the user how many nodes are on the double linked list.
		// The + 1 is there because it seems it seems like it originally miscounted by one Node.
		std::cout << "\n# of nodes in the list = " << llSize + 1 << std::endl;
		// A cout statement informing the user about all the data (numbers) in the double linked list.
		std::cout << "Data on the list: " << std::endl;
		// Set Node pointer equal to the head. 
		nPtr = head;

		// A while loop that will run a code block.
		// If Node pointer does not equal null pointer.
		// Display all the numbers in 
		while (nPtr != nullptr)
		{
			// Cout statement that will display the current number
			// Add a space.
			std::cout << nPtr->data << ' ';
			// Traverse forward with Node pointer and next pointer.
			// Keep going until all numbers have been displayed.
			nPtr = nPtr->nextPtr;
		}
		// Cout statment printing a new line.
		std::cout << std::endl;
	}
	// The else statement will be executed if the double linked list has no numbers in the list.
	else
	{
		// Cout statement informing the user that the double linked list is empty.
		std::cout << "List is empty" << std::endl;
	}
}

// Display all Nodes in reverse order.
// Template declared.
template <class T>
// Function prototype for displayReverse.
void LList<T>::displayReverse()
{
	// Temporary variable that points to Node and points to the head.
	struct Node <T> * temp = head;

	// An if statement to check if the double linked list is empty.
	if (temp == nullptr)
	{
		// Exit the if statement.
		return;
	}

	// A while loop to go to the last Node.
	while (temp->nextPtr != nullptr)
	{
		// Traverse backwards.
		temp = temp->nextPtr;
	}

	// Print statement to inform use about the list being ordered in reverse.
	printf("Reverse: ");

	// A while loop to traverse backwards using previous pointer.
	while (temp != nullptr)
	{
		// Print the data of numbers in reverse order.
		// %d =  placeholder for the integer
		printf("%d ", temp->data);
		// Traversing backwards using the previous pointer 
		temp = temp->prevPtr;
	}
	// Insert new line.
	printf("\n");
}

#endif 
