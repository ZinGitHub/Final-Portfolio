#include <iostream>
#include <thread>
#include <mutex>

// Mutex for critical section.
std::mutex mtx;

using namespace std;

// Number of threads.
static const int num_threads = 10;

// This function will be called from a thread.
void myThread(int myThreadId)
{
	mtx.lock(); // Mutex locked in myThread.
	cout << endl;
	// Display specific thread information.
	cout << "The function executing in the thread: " << myThreadId;
	mtx.unlock(); // Mutex unlocked in myThread.
}

int main()
{
	// Change the text color to green.
	system("color 0A");
	// title the program Multi-threading.
	system("title Multi-threading");

	// Declare the thread.
	thread myThreads[num_threads];

	// Launch all the threads.
	for (int i = 0; i < num_threads; ++i)
	{
		myThreads[i] = std::thread(myThread, i);
	}

	mtx.lock(); // Mutex lock in main.
	cout << endl;
	cout << "\nExecution of main";
	mtx.unlock(); // Mutex unlock in main.

	// Join all the threads.
	for (int i = 0; i < num_threads; ++i)
	{
		myThreads[i].join();
	}
	getchar();

	system("pause");
	return 0;
}