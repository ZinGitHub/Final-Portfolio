#pragma once
#include <iostream>
#include <string>
#include <list>

// The size of the hash table
const int TABLE_SIZE = 11;

// Class for the phone book 
// Class in charge of representing the entry information for the phone book
class PhoneBook 
{
	// Public access specifier
	// All attributes will be placed into public access
	public:
		// String variable storing the name correlated the phone number
		// The string name also represents the key in the hash table
		std::string name;
		// String variable stroing the phone number
		std::string phoneNumber;
		// A pointer representing the next node that has the same key
		PhoneBook* next;

		// Constructor for PhoneBook to initialize a node with the parameters string name and string phoneNumber
		PhoneBook(std::string name, std::string phoneNumber) 
		{
			// A this pointer that will point to the name object and hold the address
			this->name = name;
			// A this pointer that will point to the phoneNumber object and hold the address
			this->phoneNumber = phoneNumber;
			// A this pointer that will point to the next node and hold the address
			// Initialize the next node as NULL
			this->next = NULL;
		}
};

// Class for phone book hash table
// Class in charge of storing all the name and phone number entries into itself
class PhoneBookHashTable
{
	// Public access specifier
	// All attributes will be placed into public access
	public:
		// A pointer-to-pointer that will used to represent the hash table
		PhoneBook** hashTable;

		// Constructor for PhoneBookHashTable to initialize the PhoneBookHashTable
		PhoneBookHashTable()
		{
			// Create the initial hash table of a size of 11
			hashTable = new PhoneBook * [TABLE_SIZE];

			// A for loop that will keep running until i is no longer less than the table size whill incrementing by one
			for (int i = 0; i < TABLE_SIZE; i++)
			{
				// Initialize the hash table to NULL
				hashTable[i] = NULL;
			}
		}

		// Deconstructor for PhoneBookHashTable that will delete the memory space that was taken up by the hash table
		~PhoneBookHashTable()
		{
			//  A for loop that will keep running until i is no longer less than the table size whill incrementing by one
			for (int i = 0; i < TABLE_SIZE; i++)
			{
				// A pointer representing the entry that will equal the hash table
				PhoneBook* entry = hashTable[i];

				// A while loop that will execute the code below when the entry of the hash table does not equal NULL
				while (entry != NULL)
				{
					// The pointer representing the previous node and will be equal to the entry of the hash table
					PhoneBook* prev = entry;
					// Setting the entry node to the next node
					entry = entry->next;
					// Deallocate the memory space on the previous node and call the deconstructor for the single object
					delete prev;
				}
			}

			// Deallocate the memory space on the hashTable and call the deconstructor for the array object
			delete[] hashTable;
		}

		// Function prototype for hashFunction
		// This function will obtain the key value by adding the ASCII values of the characters in the string name
		// It will also obtain the hash value from the key
		int hashFunction(std::string name);
		// Function prototype for insertHash
		// This function will allow user to insert a name and phone number into the phone book
		void insertHash(std::string name, std::string number);
		// Function prototype for retrieveHash
		// This function will allow the user to retrieve back phone number information depending on the name the user inputted 
		int retrieveHash(std::string name);
};

