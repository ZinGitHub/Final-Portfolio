#include "Project Hash Table.h"
#include <iostream>
#include <string>


int main()
{
	// Initiate and create a hash table as myHashTable
	PhoneBookHashTable myHashTable = PhoneBookHashTable();

	// These string variables will be used to store the name and phone number for the hash table phone book
	std::string name, number;

	// An int value that will collect user iput on what function they want to interact with
	int choice;

	// A do while loop which will process everything for user interaction until user input's 3 as their choice
	do 
	{
		// Cout statement informing the user about the hash table phone book menu
		std::cout << "\Menu to Hash Table Phone Book\n";
		// Inform the user if they wish to insert a number into the hash table phone book type 1 
		std::cout << "1: To insert a name and phone number into the hash table\n";
		// Inform the user if they wish to retrieve/find a phone number from the hash table phone book type 2
		std::cout << "2: To retrieve/find a phone number using a name\n";
		// Inform the user if they want to stop the program type 3
		std::cout << "3: Exit\n";

		// Asking the user to input a number from the menu
		std::cout << "Please enter your choice (#): ";
		// Collect the number they inputted from the menu
		std::cin >> choice;
		
		// A switch statement that will execute each function depending on choice integer from user
		switch (choice)
		{
			// Execute the insert hash function if the user typed 1
			case 1:
				// Cout divider
				std::cout << "---------------------------------" << std::endl;
				// Ask the user to enter a name into the phone book
				std::cout << "Enter a name to insert: ";
				// Collect the name the user inputted
				std::cin >> name;
				// Ask the user to enter a phone number into the phone book
				std::cout << "Enter a phone number to insert: ";
				// Collect the phone number the user inputted
				std::cin >> number;
				// Execute the insertHash function with the user's number and name they inputted
				myHashTable.insertHash(name, number);
				// Jump out of loop
				break;
			case 2:
				// Ask the user to enter the name they want to search in the phone book
				std::cout << "Enter the name you want to search: ";
				// Collect the name the user inputted
				std::cin >> name;
				// Display all the phone numbers associated with the name the user inputted
				std::cout << "\nThese are the number(s) linked to the name " << name << " : ";

				// An if statement that will run a code block if the phone book has not found a phone number associated with the name the user inputted
				if (myHashTable.retrieveHash(name) == -1)
				{
					// Informing the user that there are no phone numbers associated with the name they inputted
					std::cout << "No phone number(s) found with the name: " << name <<  "\n" << std::endl;
					// Cout divider
					std::cout << "---------------------------------" << std::endl;
					// Directly jump to the beginning of the if statement for the next iteration
					continue;
				}

				// Cout divider
				std::cout << "\n---------------------------------" <<std::endl;
				// Jump out of loop
				break;
		}
	} while (choice != 3); // A while loop that will keep the menu running until user types 3

	// Return the number zero as an exit code to show that the program ran through fully with no problems.
	return 0;
}