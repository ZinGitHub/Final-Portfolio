#include "Project Hash Table.h"
#include <iostream>
#include <string>

// Function definition for hashFunction
int PhoneBookHashTable::hashFunction(std::string name)
{
	// Int variable for the key
	// The key is the sum of ASCII of all the characters present in the string name
	int key = 0;

	// A for loop that will keep running until i is no longer less than the length of the name by incrementing one
	for (int i = 0; i < name.length(); i++)
	{
		// key = key + name.at(i)
		// The .at() method will extract characters from the name string
		key += name.at(i);
	}

	// Return the value of the key module TABLE_SIZE
	// Return the remainder
	return key % TABLE_SIZE;
}

// Function definition for insertHash
void PhoneBookHashTable::insertHash(std::string name, std::string number)
{
	// If the name given has a phone number already linked to it then add the new phone number at the end in the list

	// Set the hash value to the value of the string name from the hashFunction
	int hashValue = hashFunction(name);

	// The pointer representing the previous node and will be equal to NULL
	PhoneBook* prev = NULL;
	// The pointer representing the entry and setting it to the hash value from the hash table
	PhoneBook* entry = hashTable[hashValue];

	

	// A while loop to first find the node after which this number needs to be inserted
	// A while loop that will run the code below when the entry does not equal NULL
	while (entry != NULL)
	{
		// Set the previous node and the entry equal to each other
		prev = entry;
		// entry has access to the next node
		entry = entry->next;
	}

	// An if statement that will run the code below when the hash entry is equal to NULL
	if (entry == NULL)
	{
		// Insert the number at this position

		// Initialize and create a new entry into the phone book
		entry = new PhoneBook(name, number);

		// An if statement that will run the code under when the previous node is equal to NULL
		if (prev == NULL)
		{
			// Set the entry into the hash value within the hash table
			hashTable[hashValue] = entry;
		}
		// An else statement that runs when the previous node is not equal to null
		else
		{
			// The previous node is given access to the next node and set to the entry
			prev->next = entry;
		}
	}
	// Else statement for when the entry is not equal to null
	// The name given from the user does not have a number linked hence link this number with the given name
	else 
	{
		// Entry is given access to the phoneNumber and set to the number value 
		entry->phoneNumber = number;
	}

	// Cout statement informing the user that the name they added has been added to the phone book
	std::cout << "\n[" << name << ", " << number << "]" << "\nThis contact has been added.\n";
	// Cout divider
	std::cout << "---------------------------------" << std::endl;
}

// Function definition for retrieveHash
int PhoneBookHashTable::retrieveHash(std::string name)
{
	// Boolean variable checking if the name provided by the user has a phone number linked to it
	bool occupied = false;
	// Set the hash value to the value of the string name from the hashFunction
	int hashValue = hashFunction(name);
	
	// The pointer representing the entry and setting it to the hash value from the hash table
	PhoneBook* entry = hashTable[hashValue];

	// A while loop that will run the code below when the entry does not equal NULL
	while (entry != NULL)
	{
		// If the name has multiple numbers linked to it then display all the numbers
		if (entry->name == name)
		{
			// Display all the phone numbers
			std::cout << entry->phoneNumber << " ";
			// Set the boolean value of occupied to true
			occupied = true;
		}

		// Set the entry to whatever data the entry gets from accessing the next node
		entry = entry->next;
	}

	// If occupied boolean is false then the name does not have any number linked to it
	if (!occupied) 
	{
		// Return value
		return - 1;
	}
}