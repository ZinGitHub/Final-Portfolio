#include <iostream>
#include <string>
#include <chrono>

// The structure of the node.
struct Node {
	// The data stored in the Node.
	int data;
	// A pointer reference for the previous Node.
	Node* prevPtr;
	// A pointer reference for the previous Node.
	Node* nextPtr;
};

// Create and return a new node for double linked list
struct Node* getNewNode(int data)
{
	// Using malloc to create a Node in heap memory by reserving memory in heap.
	// Allocating node
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	// Create the Node by filling in the data field as data.
	newNode->data = data;
	// Setting previous pointer as NULL.
	newNode->prevPtr = NULL;
	// Setting next Pointer as NULL.
	newNode->nextPtr = NULL;
	// Return a pointer to the Node
	return newNode;
}

//Function declaration for inserting a node into the insertion sort double linked list
void insertInsertionSortNode(struct Node** headReference, struct Node* newNode);
// Function declaration for displaying the insertion sort double linked list
void displayInsertionSortList(struct Node* head);
// Function declaration for the actual insertion sorting algorithm
void insertionSortingAlgorithm(struct Node** headReference);
// Function declaration to insert a node at the beginning of the double linked list
void pushNode(struct Node** headReference, int newData);


int main()
{
	// Iniatialize and create an empty double linked list.
	struct Node* headNode = NULL;

	// Inserting data elements for the insertion sorting algorithm
	pushNode(&headNode, 35); // Data element #1
	pushNode(&headNode, 10); // Data element #2
	pushNode(&headNode, 39); // Data element #3
	pushNode(&headNode, 82); // Data element #4
	pushNode(&headNode, 1); // Data element #5
	pushNode(&headNode, 18); // Data element #6
	pushNode(&headNode, 74); // Data element #7
	pushNode(&headNode, 92); // Data element #8
	pushNode(&headNode, 60); // Data element #9
	pushNode(&headNode, 81); // Data element #10
	pushNode(&headNode, 27); // Data element #11
	pushNode(&headNode, 13); // Data element #12
	pushNode(&headNode, 61); // Data element #13
	pushNode(&headNode, 32); // Data element #14
	pushNode(&headNode, 1); // Data element #15
	pushNode(&headNode, 89); // Data element #16
	pushNode(&headNode, 57); // Data element #17
	pushNode(&headNode, 33); // Data element #18
	pushNode(&headNode, 79); // Data element #19
	pushNode(&headNode, 43); // Data element #20
	pushNode(&headNode, 87); // Data element #21
	pushNode(&headNode, 96); // Data element #22
	pushNode(&headNode, 13); // Data element #23
	pushNode(&headNode, 73); // Data element #24
	pushNode(&headNode, 28); // Data element #25
	pushNode(&headNode, 32); // Data element #26
	pushNode(&headNode, 54); // Data element #27
	pushNode(&headNode, 98); // Data element #28
	pushNode(&headNode, 41); // Data element #29
	pushNode(&headNode, 61); // Data element #30

	// Cout statement informing the user on the content of the double linked list before insertion sorting
	std::cout << "Double linked list before insertion sorting: " << "\n";
	// function recall for displayInsertionSortList
	// Display the double linked list content before bubble sorting
	displayInsertionSortList(headNode);

	// End line
	std::cout << std::endl;
	// Divider
	std::cout << "\n==========================================================";
	// End line
	std::cout << std::endl;

	// Informing the user that the program is calculating how long it takes to insertion sort the double linked list 
	std::cout << "Calculating...\n";
	// Begin the stopwatch/ Record the start time
	auto startTime = std::chrono::system_clock::now();

	// Function recall on insertionSortingAlgorithm
	// Insertion sort the double linked list
	insertionSortingAlgorithm(&headNode);

	// Divider
	std::cout << "\n==========================================================";

	// Informing the user on the results of the double linked list after insertion sorting
	std::cout << "\nDouble list after insertion sorting: ";

	// Display the double linked list content after insertion sorting
	displayInsertionSortList(headNode);
	// Stop stopwatch/ Record the end time
	auto endTime = std::chrono::system_clock::now();
	// Calculate how long it takes to finish bubblesorting the numbers
	std::chrono::duration<double> diff = endTime - startTime;
	// Inform the user on how long it took to finish insertion sorting the data
	std::cout << "\nIt took this many seconds to complete bubble sort: " << diff.count() << " seconds\n";
	// End line
	std::cout << std::endl;

	// Return the number zero as an exit code to show that the program ran through fully with no problems.
	return 0;

}

// Function definition for insertInsertionSortNode
// Function to insert a node at the double linked list
void insertInsertionSortNode(struct Node** headReference, struct Node* newNode)
{
	// Variable that will create a node and always insert it into the current node of the double linked list
	struct Node* currentNode;

	// In case the double linked list is empty
	if (*headReference == NULL)
	{
		// Set the address of headReference to newNode
		*headReference = newNode;
	}
	// In case the node has to be inserted at the beginning of the double linked list
	else if ((*headReference)->data >= newNode->data)
	{
		// newNode has data access to the next pointer and is set to the address of headReference
		newNode->nextPtr = *headReference;
		// newNode has data access tp the next pointer and is set to the nextNode
		newNode->nextPtr->prevPtr = newNode;
		// Set the address of the headReference to newNode
		*headReference = newNode;
	}
	// In case the double linked list is not empty and is not going to be inserted at the beginning of the double linked list
	else
	{
		// Set the currentNode to the address of the headReference
		currentNode = *headReference;

		// A while loop that locate the node after which the new node is to be inserted
		while (currentNode->nextPtr != NULL && currentNode->nextPtr->data < newNode->data)
		{
			// Keep giving the current node access to the next pointer the while condition is not met
			currentNode = currentNode->nextPtr;
		}

		// Making more linkage by setting both the newNode and currentnode to each other while having access to next pointer
		newNode->nextPtr = currentNode->nextPtr;

		// In case the new node has not been inserted
		if (currentNode->nextPtr != NULL)
		{
			// NewNode has access to both the next pointer and previous pointer data
			newNode->nextPtr->prevPtr = newNode;
		}

		// Set the newNode to what the currentNode has accessed from next pointer
		currentNode->nextPtr = newNode;
		// Set the currentNode to what the newNode has accessed from previous pointer
		newNode->prevPtr = currentNode;
	}
}

// Function definition for displayInsertionSortList
// Function to print out the nodes in the double linked list
void displayInsertionSortList(struct Node* head)
{
	// A while loop that will keep displaying each element in the double linked list until NULL
	while (head != NULL)
	{
		// Print out the each element of the double linked list
		std::cout << head->data << " ";
		// Get data on the next element of the double linked list
		head = head->nextPtr;
	}
}

// Function definition for insertionSortingAlgorithm
// Function to insertion sort the double linked list
void insertionSortingAlgorithm(struct Node** headReference)
{
	// Create and intialize node as sortedNode pointer and by default set to NULL
	struct Node* sortedNode = NULL;
	// Create and intialize node as currentNode pointer and by default set to the address of headReference
	struct Node* currentNode = *headReference;

	// A while loop that will keep traversing the double linked list and insert every sorted node
	while (currentNode != NULL)
	{
		// Node to store the next element iteration
		struct Node* nextNode = currentNode->nextPtr;
		// Removing all the links to create the currentNode as a new node for another element iteration
		currentNode->prevPtr = currentNode->nextPtr = NULL;
		// Function recall on insertInsertionSortNode
		// With the parameters of currentNode and the sortedNode that has had it's reference denoted 
		// Insert the current sortedNode into the double linked list
		insertInsertionSortNode(&sortedNode, currentNode);
		// Set the currentNode to nextNode which will update the currentNode
		currentNode = nextNode;
	}

	// Set the address of headReference to sortedNode which will update headReference to point to insertion sorted double linked list
	*headReference = sortedNode;
}

// Function definition for pushNode
// Function to insert a node at the beginning of the double linked list
void pushNode(struct Node** headReference, int newData)
{
	// Using malloc to create a Node in heap memory by reserving memory in heap.
	// Allocating node
	struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
	// NewNode has access to data
	newNode->data = newData;
	// NewNode has access to next pointer and make the next of new node as head
	newNode->nextPtr = (*headReference);
	// NewNode has access to previous pointer and set it as NULL
	newNode->prevPtr = NULL;

	// An if statement that will change the previous pointer of headReference to newNode
	if ((*headReference) != NULL)
	{
		// HeadReference will point to newNode with what access it got from previous pointer
		(*headReference)->prevPtr = newNode;
	}

	// Move the headReference to point to the newNode
	(*headReference) = newNode;
}