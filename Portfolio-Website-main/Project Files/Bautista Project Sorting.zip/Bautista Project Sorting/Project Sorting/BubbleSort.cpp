#include <iostream>
#include <string>
#include <chrono>

// The structure of the node.
struct Node {
	// The data stored in the Node.
	int data;
	// A pointer reference for the next Node.
	Node* prevPtr;
	// A pointer reference for the previous Node.
	Node* nextPtr;
};

// Function declaration for inserting a node into the bubble sort double linked list.
void insertBubbleSortNode(struct Node** startReference, int data);
// Function declaration for displaying the bubble sort double linked list.
void displayBubleSortList(struct Node* start);
// Function declaration for the actual bubble sorting algorithm.
void bubbleSortingAlgorithm(struct Node* start);

int main()
{
	// Iniatialize and create an empty double linked list.
	struct Node* startNode = NULL;

	// Iniatialize and create an array that will store the numbers that will go through bubble sort
	int array[] = { 35, 10, 39, 82, 1, 18, 74, 92, 60, 81, 27, 13, 61, 32, 1, 89, 57, 33, 79, 43, 87, 96, 13, 73, 28, 32, 54, 98, 41, 61 };
	// Int variable storing the size of the double linked list
	int listSize, i;

	// A for loop that will keep executing the insertBubbleSortNode function 30 times
	for (i = 0; i < 30; i++)
	{
		// Function recall on insertBubbleSortNode
		// Denote the reference on startNode as and set as parameter
		// Including the array as the parameter to have each element in the array list go through the insertBubbleSortNode function.
		insertBubbleSortNode(&startNode, array[i]);
	}

	// Cout statement informing the user on the content of the double linked list before bubble sorting
	std::cout << "Double linked list before bubble sorting: ";
	// Function recall on displayBubleSortList
	// Display the double linked list content before bubble sorting
	displayBubleSortList(startNode);

	// End line
	std::cout << std::endl;
	// Divider
	std::cout << "\n==========================================================";
	// End line
	std::cout << std::endl;

	// Informing the user that the program is calculating how long it takes to bubble sort the double linked list 
	std::cout << "Calculating Time and Sorting...\n";
	// Begin the stopwatch/ Record the start time
	auto startTime = std::chrono::system_clock::now();

	// Function recall on bubbleSortingAlgorithm
	// Bubble sort the double linked list
	bubbleSortingAlgorithm(startNode);

	// Divider
	std::cout << "\n==========================================================";

	// Informing the user on the results of the double linked list after bubble sorting
	std::cout << "\nDouble list after bubble sorting: ";

	// Display the double linked list content after bubble sorting
	displayBubleSortList(startNode);
	// Stop stopwatch/ Record the end time
	auto endTime = std::chrono::system_clock::now();
	// Calculate how long it takes to finish bubblesorting the numbers
	std::chrono::duration<double> difference = endTime - startTime;
	// Inform the user on how long it took to finish bubble sorting the data
	std::cout << "\nIt took this many seconds to complete bubble sort: " << difference.count() << " seconds\n";
	// End line
	std::cout << std::endl;

	// Return the number zero as an exit code to show that the program ran through fully with no problems.
	return 0;
}

// Function definition for insertBubbleSortNode
// Function to insert a node at the double linked list
void insertBubbleSortNode(struct Node** startReference, int data)
{
	// Variable that will create a node and always insert it into the beginning of the double linked list
	struct Node* beginningPtr = new Node;
	// The pointer pointing at the beginning node will have access to data
	beginningPtr->data = data;
	// The beginning pointer node will have access to next pointer
	// Set that equal to the address of startReference
	beginningPtr->nextPtr = *startReference;

	// In case the double linked list is empty
	if (*startReference != NULL)
	{
		// The address pointing at startReference has access to previous pointer
		// Set that equal to the beginning pointer.
		(*startReference)->prevPtr = beginningPtr;
	}

	// The address pointing at startReference is set to the beginning pointer
	*startReference = beginningPtr;
}

// Function definition for displayBubbleSortList
// Function to print out the nodes in the double linked list
void displayBubleSortList(struct Node* start)
{
	// Node for temporary pointer set to the start
	struct Node* tempPtr = start;
	// End line 
	std::cout << std::endl;

	// A while loop that will keep displaying each element in the double linked list until NULL
	while (tempPtr != NULL)
	{
		// Print out the each element of the double linked list
		std::cout << tempPtr->data << " ";
		// Get data on the next element of the double linked list
		tempPtr = tempPtr->nextPtr;
	}
}

// Function definition for bubbleSortingAlgorithm
// Function to bubble sort double linked list
void bubbleSortingAlgorithm(struct Node* start)
{
	// Create and initialize node with beginning pouinter
	struct Node* beginningPtr;
	// Create and intialize node with linked list pointer and by default set to NULL
	struct Node* linkedListPtr = NULL;
	// Create and initialize an int variable carring data under swapped
	int swapped, i;

	// In case the double linked list is empty
	if (start == NULL)
	{
		// Terminate the execution of the function
		return;
	}

	// This do while will execute the main component of the binary sort
	// This will repeatedly swap the adjacent elements if they are in wrong order from smallest to biggest element
	do
	{
		// Set swapped int value to zero
		swapped = 0;
		// Beginnign pointer node set to the start pointer node
		beginningPtr = start;

		// A while loop that will swap the elements until the linked list pointer and beginning pointer which has access to next pointer are equal to each other
		while (beginningPtr->nextPtr != linkedListPtr)
		{
			// Swap elements if the beginning pointer has a data value less than the next pointer data value
			if (beginningPtr->data > beginningPtr->nextPtr->data)
			{
				// Swap the data values
				std::swap(beginningPtr->data, beginningPtr->nextPtr->data);
				// Set the swapped int to one
				swapped = 1;
			}

			// Beginning pointer has access to the next pointer
			beginningPtr = beginningPtr->nextPtr;
		}

		// The linked list pointer and beginning pointer are set to eachother
		// Update the linkedListPtr
		linkedListPtr = beginningPtr;
	} while (swapped); // Keep running the do while loop until swapped is false
}