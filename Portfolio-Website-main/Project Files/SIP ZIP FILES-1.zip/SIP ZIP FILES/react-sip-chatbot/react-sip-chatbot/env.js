// env.js

export const dialogflowConfig = {
  type: "service_account",
  project_id: "buddybot-kufq",
  private_key_id: "27d505f81156b0b6477c402534cca9724f00c741",
  private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCO692IkbUfItoN\nLxPTbewznvbqllZigZ8Z63SNW7WMKOf1snCzS1TRreUncJhne0pNeAeSSfQANwMP\nTwlx3oH7ChFnMoqLHliSKew9DTqDZSKnhMbIQNiIElyeZ4iK8Cvgs06tCRJHqVKj\n3gGqYUMcClMlSRnPyj8OWsjQ6xhNdnqI0cVBOXh3lY6xGQ6cxYfBnZ7KXulH6vnd\nRi+oZgkYUs5qQZqHqdLjPyA7Dcd4EJPVHPCo8mBEyyaZVXDKYgQPog4K00rkFLtB\nGth0GJMYLXxpbxWhmvh6QBAizCxC4CnDAq1j7rXPJaEc7MQhGZ83EJkWKlzapq4U\nP/I/tHDFAgMBAAECggEAB4yebk8SA+PFpFIjCDVDd4OTU9del0P1CTu2c5wPRijH\n/eKv0MyvHYdDtjZcmoS460gmkDvfS16chwO8AjuIXqAMxMh26HvRHmFgBOaMu3GN\nZ89b56qDNYbQxR4/aGVgz/TwuDOlN0tSnezFZkBOeO3zr+HBXwg2FfZGKsDsTvUZ\ntO69+uojRmjsycTWevYvWMX/9tmJu3fqJ4i71hNoZBX6EhYI9Vo5hsqCW1hwAn72\nFTQX5bi3NcfZS2NoJN4tav7Y7g95Hfm0hfD4gPG4yi6TE6I5R5NvegGEJS+9RqSX\n/6+9A9o+envi3JftCrg+cZNvTlbM7UctCLsX1Y4u0QKBgQDBVFKSnHVBwZiMhAJS\n3QbYNqE066nIt+gVhYjd9kJHtzzkjOBpaknCtS2xVqDuytnJBjdxf5u1vzCr8y8J\nG2mPsLCGwxCUqqv7IVO6GVtV/7ZGQpgPOUFGdYcAC8yZB+W2xZRS1YlJxxvJbA5Q\nwdsEwKpFYTvsy82sE7NYQPYYFQKBgQC9QF6qc4GgEbD44YUftWqeF/KwnYBDvoi7\n+CENOzVW9tPmkb0JJwyeUAvD1fbnuwbKy8cKOLsBFPQCf37nTXqyvFxpZHX0vDRp\nZ9yt6w504VhfkUBy2mdoz66bKIPIqzCuiWvciXWTBhH9ExwwlV/CIc8IKfzuUtaL\nWsdQWOzx8QKBgEhpcAAwEA9QFvZSn5gv51dmptzuhAqFL62X9ZrFmS/JZ0pnpcp2\nICiIuhOZUe//FLGh3XRqioT5lp5hGLX9iX1jfcsMFxLIFmCarAShaL9+ZuRMHy5c\nkKF2ddlDkh+jgJwDxzl7d8+lfzfjfD0tTv6pt10DPXHFKEUSn/MnacW9AoGAa3LV\njJ8h9Ji2ysd4BsXAr9vW7ZGu1keiaF57nYCFS0e+jYUnN8AU+PlnhJvBoFXeiFtk\nOZh2DCoyVAzBJ2AlDr/FFA12ryn/8+yFLbVsMs4Sl8fnOI5p8ecgMnWxRMh1TlM1\nizP8LipfIjmsYqUchiMd4Xu9YC5mIx66VRL4DHECgYEAivqKGSsDA10Y9JlobJgs\n7WrYjg+Lqr1aPugRl/btYz0kGmArr3RBwc7magWLCoyVu5bf4gQz4+3nNRV2cz5+\n7LKsSiuM15bkUrTX8rQH/al6XcGptVojjhpu9rMW2rA8u+aPt3QOX1vvMZre7R85\nK+qkLxDT7FHG3sg8yzP1XUo=\n-----END PRIVATE KEY-----\n",
  client_email: "zindialog@buddybot-kufq.iam.gserviceaccount.com",
  client_id: "101766831237263872283",
  auth_ur: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/zindialog%40buddybot-kufq.iam.gserviceaccount.com"
};
