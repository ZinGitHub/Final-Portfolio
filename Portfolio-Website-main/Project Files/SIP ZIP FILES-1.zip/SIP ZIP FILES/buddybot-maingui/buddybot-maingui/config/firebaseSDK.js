import firebase from 'firebase';

class FirebaseSDK {
  constructor() {
    if (!firebase.apps.length) {
      //avoid re-initializing
      firebase.initializeApp({
        apiKey: 'AIzaSyDc7RSAsAmCh8P_nN3slY9v1GmanDENBY0',
        authDomain: 'sip-phone-7765b.firebaseapp.com',
        databaseURL: 'https://sip-phone-7765b-default-rtdb.firebaseio.com',
        projectId: 'sip-phone-7765b',
        storageBucket: 'sip-phone-7765b.appspot.com',
        messagingSenderId: '128284774454'
      });
    }
  }
  login = async (user, success_callback, failed_callback) => {
    await firebase
      .auth()
      .signInWithEmailAndPassword(user.email, user.password)
      .then(success_callback, failed_callback);
  };
}



const firebaseSDK = new FirebaseSDK();
export default firebaseSDK;