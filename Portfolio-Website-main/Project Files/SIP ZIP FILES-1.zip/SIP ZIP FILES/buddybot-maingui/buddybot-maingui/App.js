// CODE FOR REACT NAVIGATION
import * as React from 'react';
import { Button, View, StyleSheet, SafeAreaView, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createStore } from 'redux';
import { reducer } from './redux/todoListRedux';
import Todo from './Todo';
import image1 from './Images/image1.jpg'
import image2 from './Images/image2.jpg'
import image3 from './Images/image3.jpg'
import image4 from './Images/image4.png'
import image5 from './Images/image5.png'
import image6 from './Images/image6.png'
import image7 from './Images/image7.png'
import RealLogoGUI from './Images/RealLogoGUI.png'


const Separator = () => <View style={styles.separator} />;


function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Button
        title="Go to Main Menu"
        onPress={() => navigation.navigate('Main Menu')}
      />
    </View>  
  );
}

function ProfileScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <View>
        <Button
          title="Go to Chatbot"
          onPress={() => navigation.navigate('Chatbot')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Meditation Tool"
          onPress={() => navigation.navigate('Meditation')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Breathing Tool"
          onPress={() => navigation.navigate('Breathing')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Yoga Tool"
          onPress={() => navigation.navigate('Yoga')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Reminder Tool"
          onPress={() => navigation.navigate('Reminder')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Journal Tool"
          onPress={() => navigation.navigate('Journal')}
        />
      </View>
      <Separator />
      <View>
        <Button
          title="Puzzle Tool"
          onPress={() => navigation.navigate('Puzzles')}
        />
      </View>
      <Separator />
      <View>
        <Button title="Go back" onPress={() => navigation.goBack()} />
      </View>
    </SafeAreaView>
  );
}

function ChatbotScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={image1} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View> 
  );
}

function MeditationScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Image source={image2} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}

function BreathingScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Image source={image3} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}

function YogaScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={image4} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}


function ReminderScreen({ navigation }) {
  var store = createStore(reducer);
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Todo store={store} />
      <Image source={image5} style={{ width: 305, height: 159}} /> 
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}


function JournalScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={image6} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}

function PuzzleScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={image7} style={{ width: 305, height: 159}} />
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}

function SettingsScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Button title="Go back" onPress={() => navigation.goBack()} />
    </View>
  );
}


const Stack = createStackNavigator();

function MyStack() {
  return (
    <Stack.Navigator> 
      <Stack.Screen name="BuddyBot" component={HomeScreen} />
      <Stack.Screen name="Chatbot" component={ChatbotScreen} />
      <Stack.Screen name="Main Menu" component={ProfileScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="Meditation" component={MeditationScreen} />
      <Stack.Screen name="Breathing" component={BreathingScreen} />
      <Stack.Screen name="Yoga" component={YogaScreen} />
      <Stack.Screen name="Reminder" component={ReminderScreen} />
      <Stack.Screen name="Journal" component={JournalScreen} />
      <Stack.Screen name="Puzzles" component={PuzzleScreen} />
    </Stack.Navigator>
  );
} 

export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    marginHorizontal: 16,
    margin: 10,
    marginTop: 30,
    padding: 30,
  },
  //title: {
    //textAlign: 'center',
    //marginVertical: 8,
  //},
  //fixToText: {
    //flexDirection: 'column',
    //justifyContent: 'space-between',
  //},
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});

// Code fo NavigatoeIOS only targeting IOS
//<NavigatorIOS
  //initialRoute={{
    //component: HomeScreen,
    //title: 'Title for screen',
    //passProps: { myProp: 'foo'},
  //}}
///>
// END of Code fot NavigatoeIOS only targeting IOS

// END OF CODE FOR REACT NAVIGATION

// CODE FOR TO-DO LIST
//import { createStore } from 'redux';
//import React, { Component } from 'react';
//import { View } from 'react-native';

//import { reducer } from './redux/todoListRedux';
//const store = createStore(reducer);

//import Todo from './Todo';

//export default class App extends Component {

  //render() {

    //return (
      //<View style={{ flex: 1, backgroundColor: '#dddddd', alignContent: 'center', justifyContent: 'center'}}>
        //<Todo store={store} />
      //</View>
    //);
  //}
//}
// END OF TO-DO LIST CODE
