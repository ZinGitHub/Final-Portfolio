#include<iostream>
#include<string>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <ctime>
#include "Interactive.h"

using namespace std;
using std::cout;
using std::cin;
using std::endl;
using std::string;




int main()
{
	// Changes the title of the program to NSA Agent Interactive Story.
	system("title Dystopian Interactive Story");
	// Changes the background to black and the font color green.
	system("color 0A");

	// Description for user on what this is.
	cout << "*** Hello, this program is an interactive story about you as an employee working at a company that is hiding secrets. *** \n";
	cout << "*** This program will ask you on what you would as the employee. *** \n";
	cout << "*** The story will give you different scenarios in which you will be provided a menu to choose your options. *** \n";

	// All the Interactive classes
	Interactive Organization;
	Interactive Introduction;
	Interactive Instructions;
	Interactive Help;
	Interactive Game;
	Interactive StoryAction;
	Interactive TextStory;
	Interactive NumberText;




	// Function in charge of Introducing user. 
	Organization.ScreenFormat();
	Introduction.WelcomeUserToGame(); // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of telling introduction.  
	Introduction.StoryIntroduction();    // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of collecting number data from user and using the number data.
	NumberText.WonderingUser();   // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of intruding the user to the situation of the story.  
	StoryAction.HackerInfiltration();   // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of telling user instructions. 
	Instructions.StoryInteractionGameInstructions(); // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of Giving user advise.   
	Help.UserHelp(); //FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of the word decryption mini-game.
	Game.StoryInteractionGame(); // FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of congratulating the user for decrypting the word.  
	StoryAction.CongratulateUserForDecryptingWord(); //FUNCTION CALL
	Organization.ScreenFormat();

	// Function in charge of collecting text from the user and using the text data.
	TextStory.GetTextFromUser();  // FUNCTION CALL
	Organization.ScreenFormat();

	// Prevents the program from just running and not showing the user the console box.
	system("pause");
	// A exit number for the program. If zero is returned at the of the program, then the program ran successfully.
	return 0;
}


// ostreaming the value of the cards and their suit.
ostream& operator<<(ostream& os, const Card& xCard)
{
	// Create constant string of all the available values of each card.
	const string CardValue[] = { "0 ", "Ace ", "2 ", "3 ", "4 ", "5 ", "6 ", "7 ", "8 ", "9 ", "10 ", "Jack ", "Queen ", "King " };
	// Create constant string of all the available suits of the cards.
	const string SUITS[] = { "clubs", "diamonds", "hearts", "spades" };

	// If the card is facing up then display the value and the suit.
	if (xCard.X_IsFaceUp)
	{
		os << CardValue[xCard.X_CardValue] << SUITS[xCard.X_Suit];
	}
	else
	{
		// Illustrate the cards are hidden from player view.
		os << "XX";
	}

	return os;
}

// ostreaming the name of the other player.
ostream& operator<<(ostream& os, const OtherPlayer& xOtherPlayer)
{
	os << xOtherPlayer.X_Name << ":\t";

	// Create the card vector depended on pCard.
	vector<Card*>::const_iterator pCard;
	if (!xOtherPlayer.X_Cards.empty())
	{
		// Display the cards of other player.
		for (pCard = xOtherPlayer.X_Cards.begin();
			pCard != xOtherPlayer.X_Cards.end();
			++pCard)
		{
			os << *(*pCard) << "\t";
		}


		if (xOtherPlayer.ValueTotal() != 0)
		{
			// Display the total value of the hand from other player.
			cout << "(" << xOtherPlayer.ValueTotal() << ")";
		}
	}
	else
	{
		// Inform the player (program user) that the value of the cards in the other player is empty.
		os << "[EMPTY]";
	}

	return os;
}
