#include "Interactive.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cctype>
#include <boost/algorithm/string.hpp>

using namespace std;

// A double cast *pointer* GetWeeklyHours function definition (ASSIGNED THE ADDRESS FOR GetWeeklyHours).
double &GetWeeklyHours()
{

	int workHours;

	// Collecting the user input (GATHERING VALUE FOR INT workHours).
	cout << "How many hours DO YOU EXPECT to work this week: ";
	cin >> workHours;

	// The variable double cast h is equal to the hours working in a week.
	double h = workHours;
	// Double cast *pointer* hours variable initialized and is equal to h (ASSIGNED THE ADDRESS FOR THE VARIABLE hours TO VARIABLE h).
	double &hours = h;

	// Return the value of hours.
	return hours;
}

// A doubled cast *pointer* GetSalary function definition (POINTER INITIALIZED).
double *GetSalary()
{

	int money;

	// Collecting the user input (GATHERING VALUE FOR INT money).
	cout << "How much money DO YOU EXPECT TO get paid per the hour: ";
	cin >> money;

	// The double cast variable salary is equal to the money being paid per hour.
	double salary = money;
	// The double cast *pointer* variable HourlySalary is equal to salary (ASSIGNED THE ADDRESS FOR THE VARIABLE salary to POINTER VARIABLE HourlySalary).
	double *HourlySalary = &salary;

	// Return the value of HourlySalary.
	return HourlySalary;
}


Interactive::Interactive()
{
}

// Function definition of WelcomeUserToGame.
void Interactive::WelcomeUserToGame()
{

	string protagonist;

	// Gather and collect the information on the protagonist name.
	cout << "Enter your protagonist name: ";
	getline(cin, protagonist);



	// cout statement for the introduction.
	cout << "* Welcome to Dystopian INC. " << "[AGENT " << boost::to_upper_copy(protagonist) << "]" << ". Congratulations on getting hired, good luck on your first day! *\n";
	SubScreenFormat();
	cout << "* We would like you to take a survey on employee salary evaluation. *\n";
	cout << "* Input information depending on your desires, if you keep being a loyal employee we'll consider your survey as higher priority. *\n";

	// Double cast hours is equal to the function GetWeeklyHours.
	double hours = GetWeeklyHours();
	// Double cast salary is equal to the function GetSalary (POINTER DEREFERENCE).
	double salary = *GetSalary();
	// Double cast WeeklySalary is equal to the variables hours multiplied by salary.
	double WeeklySalary = hours * salary;
	// Double cast MonthlySalary is equal to WeeklySalary multiplied by 4.
	double MonthlySalary = WeeklySalary * 4;
	// Double cast YearlySalary is equal to WeeklySalary multiplied by 52.
	double YearlySalary = WeeklySalary * 52;

	// Telling the user their salary by each time category.
	cout << "\t - Weekly Hours:  " << hours << endl;
	cout << "\t - Hourly Salary: " << salary << endl;
	cout << "\t - Weekly Salary: " << WeeklySalary << endl;
	cout << "\t - Monthly Salary: " << MonthlySalary << endl;
	cout << "\t - Yearly Salary: " << YearlySalary << endl;
	system("pause");
	SubScreenFormat();


	cout << "* Thank you for your input, you MUST now hand us the following objects. *\n";


	// A string vector that obtains all string elements.
	vector<string> inventory;
	// Add the element "wallet" to the end.
	inventory.push_back("\t - Wallet");
	// Add the element "phone" to the end.
	inventory.push_back("\t - Phone");
	// Add the element "keys" to the end.
	inventory.push_back("\t - Finger print");

	// Function in charge of displaying the inventory items on the screen (PARAMETER AT THE POINTER ADDRESS inventory).
	display(&inventory);


	cout << "* Remember to always come back to work without any distractions or form of outside communication, or you will be punished. *\n";
	cout << "* WE ARE ALWAYS WATCHING! *\n";
	cout << "* Now have a nice day at work " << protagonist << " *.\n";
	system("pause");

}

// Function definition of ScreenFormat.
void Interactive::ScreenFormat()
{
	// cout used in formatting.
	cout << "\n\n";
	cout << "=====================================================================================================================\n";
	cout << "=====================================================================================================================\n";
	cout << "=====================================================================================================================\n";
	cout << "\n\n";
}

// Function definition of SubScreenFormat.
void Interactive::SubScreenFormat()
{
	// Used for sub-formatting.
	cout << "_____________________________________________________________________________________________________________________\n";
}

// Function definition of UserHelp.
void Interactive::UserHelp()
{
	// Statement to tell the user to type hint if they want a hint or quit to quit.
	cout << "*** Type 'hint' for a hint. ***\n";
	cout << "***Type 'quit' to quit the game. ***\n\n";
}

// Function definition of StoryIntroduction.
void Interactive::StoryIntroduction()
{
	// Introduction of the story.
	cout << "* You sit down at your office desk and look around. *\n";
	cout << "* You start getting aware of your work environment and start to space out. *\n";
	cout << "* You snap out of your thinking state and start doing your job. *\n\n";
	system("pause");
}

// Function definition of HackerInfiltration.
void Interactive::HackerInfiltration()
{
	cout << "* You start noticing your computer slowing down. *\n";
	cout << "* You then start hearing other people complain about how there computers are getting slower. *\n";
	cout << "* ... *\n";
	cout << "* YOUR COMPUTER HAS BEEN HACKED. IT'S NOW LOCKED UNDER AN ENCRYPTION BY THE HACKER GROUP MANGO SIX. *\n";

	cout << "\t\t\t	\n\n";
	cout << "\t\t\t                 uu$$$$$$$$$$$uu                 \n\n";
	cout << "\t\t\t              uu$$$$$$$$$$$$$$$$$uu              \n\n";
	cout << "\t\t\t             u$$$$$$$$$$$$$$$$$$$$$u             \n\n";
	cout << "\t\t\t            u$$$$$$$$$$$$$$$$$$$$$$$u            \n\n";
	cout << "\t\t\t           u$$$$$$$$$$$$$$$$$$$$$$$$$u           \n\n";
	cout << "\t\t\t           u$$$$$$$$$$$$$$$$$$$$$$$$$u           \n\n";
	cout << "\t\t\t           u$$$$$$"   "$$$"   "$$$$$$u           \n\n";
	cout << "\t\t\t           $$$$        u$u        $$$$           \n\n";
	cout << "\t\t\t            $$$u       u$u       u$$$            \n\n";
	cout << "\t\t\t            $$$u      u$$$u      u$$$            \n\n";
	cout << "\t\t\t              $$$$uu$$$   $$$uu$$$$              \n\n";
	cout << "\t\t\t               $$$$$$$     $$$$$$$               \n\n";
	cout << "\t\t\t                u$$$$$$$u$$$$$$$u                \n\n";
	cout << "\t\t\t                 u$ $ $ $ $ $ $u                 \n\n";
	cout << "\t\t\t      uuu        $$u$ $ $ $ $u$$       uuu       \n\n";
	cout << "\t\t\t     u$$$$        $$$$$u$u$u$$$       u$$$$      \n\n";
	cout << "\t\t\t      $$$$$uu       $$$$$$$$$      uu$$$$$$      \n\n";
	cout << "\t\t\t    u$$$$$$$$$$$uu           uuuu$$$$$$$$$$      \n\n";
	cout << "\t\t\t    $$$$$$$$$$$$$$$$$uuu   uu$$$$$$$$$$$$$$      \n\n";
	cout << "\t\t\t                $$$$$$$$$$$uu$$$$                \n\n";
	cout << "\t\t\t               uuuu$$$$$$$$$$$$$uuu              \n\n";
	cout << "\t\t\t      u$$$uuu$$$$$$$$$uu   $$$$$$$$$$$uuu$$$     \n\n";
	cout << "\t\t\t      $$$$$$$$$$                 $$$$$$$$$$$     \n\n";
	cout << "\t\t\t        $$$$$                         $$$$       \n\n";
	cout << "\t\t\t         $$$                          $$$$       \n\n";
	system("pause");
}

// Function definition of StoryInteractionGameInstructions.
void Interactive::StoryInteractionGameInstructions()
{
	// Statement introducing the game and giving instructions.
	cout << "* You realize that you can unlock your computer by decrypting your computer. *\n";
	cout << "* Unscramble the letters to make a word. *\n";
	cout << "* type the words that are under quotes for example------> the word \"yes\" is under quotes so it's a word that you can type. *\n";
	system("pause");
}

// Function definition of StoryInteractionGame.
void Interactive::StoryInteractionGame()
{
	bool playAgain = true;
	int result = 0;

	// An enum to define the user data types and containing them into integral constants.
	enum fields { WORD, HINT, NUM_FIELDS };
	// const int NUM_WORDS is the number of words in the jumble solver.
	const int NUM_WORDS = 10;

	// A while statement that will run the program until the user doesn't want to play again.
	while (playAgain == true)
	{
		// const string WORDS[NUM_WORDS] [NUM_FIELDS] is to display the word and the hint.
		const string WORDS[NUM_WORDS][NUM_FIELDS] =
		{
		{"Computer", "An electronic device that stores and processes data in binary form, according to instructions from a program.." },
		{"Malware", "Software designed to disrupt, damage, or gain unauthorized access to a computer system."},
		{"Hacker", "A person who uses a computer to gain unauthorized access to data."},
		{"Operation", "An organized activity with a codename."},
		{"Undercover", "Someone who works secretly mostly for investigation purposes."},
		{"Monitor", "A tool used to observe, check, and keep a record of a process."},
		{"Espionage", "The practice of spying of spying on someone to tamper with the target."},
		{"Spy", "A person who collects information on their target, without their notice."},
		{"Encryption", "The process of encoding a message or information."},
		{"Classified", "Information that is private, secured, and only a certain group of people can look at."}
		};

		// An srand to put a seed in the random generator.
		srand(static_cast<unsigned int>(time(0)));
		//  An integer to randomly choose the word from the word list.
		int choice = (rand() % NUM_WORDS);
		// A string variable that will collect the word from the word list.
		string jumbleWord = WORDS[choice][WORD];
		// A string variable for the hint correlating to the word list.
		string jumbleHint = WORDS[choice][HINT];

		// A string to correlate the word chosen from the list and the word that will be jumbled.
		string jumble = jumbleWord;
		// The integer for the size of the jumbled word.
		int length = jumble.size();

		// A for loop that will start at zero, will end when i is less than length, and will increment by one and then output i. (This is essential to jumble the words).
		for (int i = 0; i < length; ++i)
		{
			// An integer to randomize the length for index1.
			int index1 = (rand() % length);
			// An integer to randomize the length for index2.
			int index2 = (rand() % length);
			// A char variable that contains the jumble of index1.
			char temp = jumble[index1];
			// the jumble of index1 is now the jumble of index2.
			jumble[index1] = jumble[index2];
			// jumble[index2] returns back to the temp char variable.
			jumble[index2] = temp;
		}


		cout << "The jumble is: " << jumble;

		// A string variable to contain the player's guess.
		string guess;
		cout << "\n\nYour guess: ";
		cin >> guess;

		// A while statement that will keep running the program unless the user type's the correct word or quit.
		while ((guess != jumbleWord) && (guess != "quit"))
		{
			// A if statement that will output a hint if user asks for a hint.
			if (guess == "hint")
			{
				cout << jumbleHint;
			}
			// An else statement that will execute if user's guess is wrong and didn't type hint or quit.
			else
			{
				cout << " * Incorrect, please try again. *";
			}

			// Collect user input.
			cout << "\n\nYour guess: ";
			cin >> guess;
		}

		// A if statement that will execute if the player guessed correctly.
		if (guess == jumbleWord)
		{
			cout << "\n* That is correct, congratulations you have unlocked your computer. *\n";
		}

		// Statement asking if user want's to play again (SPECIFICALLY WITH DECYPTING WORD GAME).
		cout << "Would you like to try to decyrpt another word?:" << endl;
		SubScreenFormat();

		// Stating the words to type.
		cout << "[TYPE THE NUMBER]\n";
		cout << "\"1\"\n";
		cout << "\"2\"\n";
		SubScreenFormat();

		// Gather the results on whether the user typed 1 or 2.
		cout << "1: Yes" << endl;
		cout << "2: No" << endl;
		cout << ">";
		cin >> result;

		// The if else statement that will either make the program loop back or not.
		if (result == 1)
		{
			// The user has typed 1 which mean's the program will run again.
			playAgain = true;
		}
		else if (result == 2)
		{
			// The user has typed 2 which mean's the the program will not run again
			playAgain = false;
		}
		else
		{
			// The user typed something else besides 1 or 2. So the program will still not run again.
			playAgain = false;
		}
	}
}

// Function definition of CongratulateUserForDecryptingWord.
void Interactive::CongratulateUserForDecryptingWord()
{
	cout << "* Congratulations you have decrypted your computer. *\n";
}

// Function definition of GetTextFromUser.
void Interactive::GetTextFromUser()
{
	// String variables for the function.
	string UnkownFolder, yes, no, FolderAction, destroy, investigate, FileActionConflicted, job, inform, leak, quit, work;
	cout << "* Once you've gained access of your computer you see a folder called \"CLICK ME!\". *\n";
	SubScreenFormat();

	cout << "[TYPE THE WORD]\n";
	cout << "1:\"yes\"\n";
	cout << "2:\"no\"\n";
	SubScreenFormat();

	// Collect user input on whether they decide to open the folder.
	cout << "Do You open the folder?: \n";
	cin >> UnkownFolder;

	// The if statement that branches the story if "yes" is typed.
	if (UnkownFolder == "yes")
	{
		ScreenFormat();
		cout << "* You decide to open the folder due to curiosity. *\n";
		cout << "* You see a lot of information on the NSA and all of it is classified information. *\n";
		SubScreenFormat();

		cout << "[TYPE THE WORD]\n";
		cout << "1:\"destroy\"\n";
		cout << "2:\"inform\"\n";
		cout << "3:\"investigate\"\n";
		system("pause");
		SubScreenFormat();

		// Collect user input on what they want to do with the folder.
		cout << "* Do you destroy the file, inform your supervisor, or investigate more?: \n";
		cin >> FolderAction;

		// The if statement that branches the story depending if "destroy", "inform", or "investigate" is typed.
		if (FolderAction == "destroy")
		{
			// Story Scenario.
			ScreenFormat();
			cout << "* You destroy the file and assist in recovering computers. *\n";
			cout << "* You continue working at and soon receive a promotion Dystopian INC. *\n";
			cout << "* You live the rest of your life like an average employee. *\n";
			cout << "*** [PLAYER HAS COMPLETED STORY WITH A PEACEFUL ENDING!] ***\n";
			system("pause");
			ScreenFormat();
		}
		else if (FolderAction == "inform")
		{
			// Story Scenario.
			ScreenFormat();
			cout << "* You inform your supervisor. *\n";
			cout << "* Your supervisor obtains the folder through a quarantine procedure. *\n";
			cout << "* Your supervisor says thank you for telling me. *\n";
			cout << "* A couple days later you hear on the news and by co-workers that employees and former employees have been arrested in  corporate espionage. *\n";
			cout << "* You continue working at and soon receive a promotion Dystopian INC. *\n";
			cout << "* You live the rest of your life like an average employee. *\n";
			cout << "*You still wonder why did employees and former employees commit corporate espionage?\n";
			cout << "*** [PLAYER HAS COMPLETED STORY WITH A PEACEFUL BUT CONFUSING ENDING!] ***\n";
			system("pause");
			ScreenFormat();
		}
		// Else if statement that give's the story scenario if user typed "investigate".
		else if (FolderAction == "investigate")
		{
			ScreenFormat();
			cout << "* You investigate more and realize that all this classified information details on how and who Dystopian INC spy on. *\n";
			cout << "* You start feeling concerned. *\n";
			cout << "* You start questioning on whether you should leak this information for the people to know what Dystopian INC has been doing. *\n";
			SubScreenFormat();

			cout << "[TYPE THE WORD]\n";
			cout << "1:\"destroy\"\n";
			cout << "2:\"leak\"\n";
			SubScreenFormat();

			// Collect user input on what they want to do with the classified information.
			cout << "* Do you leak this classified information or destroy the file?: \n";
			cin >> FileActionConflicted;

			// An if statement that give's the story scenario if user types "destroy" at this moment.
			if (FileActionConflicted == "destroy")
			{
				ScreenFormat();
				cout << "* You destroy the file and assist in recovering computers at Dystopian INC. *\n";
				cout << "* You get promoted for your work and continue working at Dystopian INC. *\n";
				SubScreenFormat();

				cout << "[TYPE THE WORD]\n";
				cout << "1:\"work\"\n";
				cout << "2:\"quit\"\n";

				SubScreenFormat();

				// Collect user input on whether they want to continue working.
				cout << "* You work at Dystopian INC for a while but feel conflicted about your job. Do you keep working or quit?: \n";
				cin >> job;

				// An if statement that give's the story scenario if user types "work". 
				if (job == "work")
				{
					// Story Scenario.
					ScreenFormat();
					cout << "* You continue to work. *\n";
					cout << "* You can't seem to not stop feeling conflicted for the rest of your career at Dystopian INC. *\n";
					cout << "*** [PLAYER HAS COMPLETED STORY WITH CONFLICTED ENDING!] ***\n";
					ScreenFormat();
				}
				// An else if statement that give's the story scenario if user types "quit".
				else if (job == "quit")
				{
					// Story Scenario.
					ScreenFormat();
					cout << "* After a while at working at Dystopian INC you decide to quit from and get a job somewhere else. *\n";
					cout << "* As time goes on you've felt anger as you've realized that Dystopian INc has been spying on ordinary citizens. *\n";
					cout << "* You start developing a sense of revenge... *\n";
					cout << "* You decide to hack into the bank account of Dystopian INC. *\n";
					system("pause");

					int companyAccount = 500000000;
					int employeeHackerAccount = 0;

					cout << "Dystopia Incorporated Account: " << companyAccount << "\n";
					cout << "Employee (you) Hacker Account: " << employeeHackerAccount << "\n";
					SubScreenFormat();

					cout << "Switching all transactions between employee hacker and Dystopia Incorporated...\n";
					cout << "Money transaction between employee hacker and Dystopia Incorporated complete.\n";
					cout << "\t\t\t	\n\n";
					cout << "\t\t\t                 uu$$$$$$$$$$$uu                 \n\n";
					cout << "\t\t\t              uu$$$$$$$$$$$$$$$$$uu              \n\n";
					cout << "\t\t\t             u$$$$$$$$$$$$$$$$$$$$$u             \n\n";
					cout << "\t\t\t            u$$$$$$$$$$$$$$$$$$$$$$$u            \n\n";
					cout << "\t\t\t           u$$$$$$$$$$$$$$$$$$$$$$$$$u           \n\n";
					cout << "\t\t\t           u$$$$$$$$$$$$$$$$$$$$$$$$$u           \n\n";
					cout << "\t\t\t           u$$$$$$"   "$$$"   "$$$$$$u           \n\n";
					cout << "\t\t\t           $$$$        u$u        $$$$           \n\n";
					cout << "\t\t\t            $$$u       u$u       u$$$            \n\n";
					cout << "\t\t\t            $$$u      u$$$u      u$$$            \n\n";
					cout << "\t\t\t              $$$$uu$$$   $$$uu$$$$              \n\n";
					cout << "\t\t\t               $$$$$$$     $$$$$$$               \n\n";
					cout << "\t\t\t                u$$$$$$$u$$$$$$$u                \n\n";
					cout << "\t\t\t                 u$ $ $ $ $ $ $u                 \n\n";
					cout << "\t\t\t      uuu        $$u$ $ $ $ $u$$       uuu       \n\n";
					cout << "\t\t\t     u$$$$        $$$$$u$u$u$$$       u$$$$      \n\n";
					cout << "\t\t\t      $$$$$uu       $$$$$$$$$      uu$$$$$$      \n\n";
					cout << "\t\t\t    u$$$$$$$$$$$uu           uuuu$$$$$$$$$$      \n\n";
					cout << "\t\t\t    $$$$$$$$$$$$$$$$$uuu   uu$$$$$$$$$$$$$$      \n\n";
					cout << "\t\t\t                $$$$$$$$$$$uu$$$$                \n\n";
					cout << "\t\t\t               uuuu$$$$$$$$$$$$$uuu              \n\n";
					cout << "\t\t\t      u$$$uuu$$$$$$$$$uu   $$$$$$$$$$$uuu$$$     \n\n";
					cout << "\t\t\t      $$$$$$$$$$                 $$$$$$$$$$$     \n\n";
					cout << "\t\t\t        $$$$$                         $$$$       \n\n";
					cout << "\t\t\t         $$$                          $$$$       \n\n";

					// Function in charge of the hacked transaction (hackedTransaction).
					hackedTransaction(companyAccount, employeeHackerAccount);

					cout << "Dystopia Incorporated Account: " << companyAccount << "\n";
					cout << "Employee Hacker Account: " << employeeHackerAccount << "\n";
					SubScreenFormat();

					cout << "* Now that you've hurt Dystopian INC economically, you decide to use that money to globalize an effort against massive surveillance. *\n";
					cout << "* Yet you still feel anxious and worried both from the action you've done and the thought of who else could be spying on everyone. *\n";
					cout << "*** [PLAYER HAS COMPLETED STORY WITH WORRIED ENDING!] ***\n";
					system("pause");
					ScreenFormat();
				}
			}
			// An else if statement that give's the story scenario if user types "leak".
			else if (FileActionConflicted == "leak")
			{
				// Story Scenario.
				ScreenFormat();
				cout << "* You decide to leak out the information. *\n";
				cout << "* It took a lot of planning and obstacles to figure out how to obtain the folder. *\n";
				cout << "* Your at home looking at your computer realizing what you'll do will turn you into a criminal in the eyes of the government. *\n";
				cout << "* You sigh heavily...And leak out the information in the file. *\n";
				cout << "* You've been granted asylum in Iceland. *\n";
				cout << "* Soon news organizations start to reveal the leaks to the public. *\n";
				cout << "* Many protests have occurred around the world against Dystopian INC. *\n";
				cout << "* Many if not everyone around the world see you as a hero. *\n";
				cout << "* You believe what you did was right and the people had to know that Dystopian INC was spying on ordinary citizens. *\n";
				cout << "* But Dystopian INC see you as a traitor and will without hesitation arrest you, with the help of the government. *\n";
				cout << "*** [PLAYER HAS COMPLETED STORY WITH WHISTLE BLOWER ENDING!] ***\n";
				system("pause");
				ScreenFormat();
			}
		}
	}
	// An else if statement that branches the story when user types "no".
	else if (UnkownFolder == "no")
	{
		ScreenFormat();
		cout << "* You don't open the folder. *\n";
		SubScreenFormat();

		cout << "[TYPE THE WORD]\n";
		cout << "1:\"destroy\"\n";
		cout << "2:\"inform\"\n";
		SubScreenFormat();

		// Collect user input on what they want to do with the file.
		cout << "Do you destroy the file or inform your supervisor?: \n";
		cin >> FolderAction;

		// An if statement that give's the story scenario if user types "destroy".
		if (FolderAction == "destroy")
		{
			// Story Scenario.
			ScreenFormat();
			cout << "* You destroy the file and assist in recovering computers at Dystopian INC. *\n";
			cout << "* You get promoted for your work and continue working at Dystopian INC. *\n";
			cout << "* You live the rest of your life like an average employee. *\n";
			cout << "*** [PLAYER HAS COMPLETED STORY WITH A PEACEFUL ENDING!] ***\n";
			system("pause");
			ScreenFormat();
		}
		// An else if statement that give's the story scenario if user types "inform"
		else if (FolderAction == "inform")
		{
			// Story Scenario.
			ScreenFormat();
			cout << "* You inform your supervisor. *\n";
			cout << "* Your supervisor obtains the folder through a quarantine procedure. *\n";
			cout << "* Your supervisor says thank you for telling me. *\n";
			cout << "* A couple days later you hear on the news and by co-workers that employees and former employees have been arrested in corporate espionage. *\n";
			cout << "* You get promoted for your work and continue working at Dystopian INC. *\n";
			cout << "* You live the rest of your life like an average employee. *\n";
			cout << "* You still wonder why did employees and former employees commit espionage? *\n";
			cout << "*** [PLAYER HAS COMPLETED STORY WITH A PEACEFUL BUT CONFUSING ENDING!] ***\n";
			system("pause");
			ScreenFormat();
		}
	}
}

// Function Definition for GetNumbersFromUser.
void Interactive::WonderingUser()
{
	int SugarCubes;
	bool PlayAgain = true;
	int result = 0;
	string yes, no, PlayBlackjack;

	cout << "* All of a sudden your in a mood for some green herbal tea. *\n";
	cout << "* You leave your desk to go get some green herbal tea. *\n";
	cout << "How many cubes of sugar do you decide to put in your tea?: \n";
	system("pause");
	SubScreenFormat();

	// Collect user input on how many sugar cubes.
	cout << "[TYPE ANY NUMBER]\n";
	cin >> SugarCubes;

	// An if else statement that branches the direction of the story depending on what number the user typed.
	if (SugarCubes < 2 || SugarCubes == 2)
	{
		// Story Scenario.
		cout << "* You decided to go safe to prevent a sugar crash on your first day. * \n";
		SubScreenFormat();
	}
	else if (SugarCubes > 2 && SugarCubes != 2)
	{
		// Story Scenario.
		cout << "* You want some extra sugar to keep you more awake and energetic for your first day. *\n";
		SubScreenFormat();
	}
	cout << "* You go back to your desk and work after your done with your tea. *\n";

	cout << "* You start working on your tasks... *\n";
	cout << "* You start feeling bored as the mundane tasks start chipping away at your morale. *\n";
	cout << "* You start to sigh as the boredom gets to you. *\n";
	cout << "* An employee starts to notice that you are looking bored. *\n";
	cout << "* He asks if you want to play a game of tic-tac-toe. *\n";


	// A while loop to continue playing hangman depending if user wants to.
	while (PlayAgain == true)
	{
		// The amount of chances the user has.
		const int MAX_WRONG = 8;

		// The collection of possible words to guess.
		vector<string> Word;
		Word.push_back("GUESS");
		Word.push_back("HANGMAN");
		Word.push_back("WORK");
		Word.push_back("SURVEILLANCE");
		Word.push_back("WORK");
		Word.push_back("TEA");
		Word.push_back("FREEDOM");

		// Randomize the letter placement of the word.
		srand(static_cast<unsigned int>(time(0)));
		random_shuffle(Word.begin(), Word.end());

		// The word that will be guessed.
		const string Correct_Word = Word[0];
		// Number of incorrect guesses.
		int Wrong = 0;
		// Word tthat the user guessed.
		string WordUsed(Correct_Word.size(), '-');
		// Letters that the user guessed.
		string LetterGuessed = "";

		// Hangman introduction.
		cout << "*** Welcome to the mini-game of Hangman. ***\n";
		cout << "*** Try to guess what the word is by inputting letters that correlate to the word. ***\n";
		cout << "*** Good luck! ***\n";


		while ((Wrong < MAX_WRONG) && (WordUsed != Correct_Word))
		{
			// Display the user the amount wrong they have and letters they've typed.
			cout << "\n\nYou have " << (MAX_WRONG - Wrong) << " incorrect guesses left.\n";
			cout << "\nYou've used the following letters:\n" << LetterGuessed << endl;
			cout << "\nSo far, the word is:\n" << WordUsed << endl;

			// User enters their guess, collect input.
			char Guess;
			cout << "\n\nEnter your guess: ";
			cin >> Guess;

			// Make the letter uppercase because the word that is being guessed is in all uppercase..
			Guess = toupper(Guess);

			while (LetterGuessed.find(Guess) != string::npos)
			{
				// Tell you user they have already guessed that letter.
				cout << "\nYou've already guessed " << Guess << endl;
				// User enters their guess, collect input.
				cout << "Enter your guess: ";
				cin >> Guess;
				// Uppercase guess letter.
				Guess = toupper(Guess);
			}

			LetterGuessed += Guess;

			if (Correct_Word.find(Guess) != string::npos)
			{
				// Tell theuser they have guessed the right word.
				cout << "That's right! " << Guess << " is in the word.\n";

				// Update WordUSed to include the newly guessed letters.
				for (unsigned int i = 0; i < Correct_Word.length(); ++i)
				{
					if (Correct_Word[i] == Guess)
					{
						WordUsed[i] = Guess;
					}
				}
			}
			else
			{
				// Tell the user that the word they attempted to guess is wrong.
				cout << "Sorry, " << Guess << " isn't in the word.\n";
				++Wrong;
			}
		}

		// Inform user that they lost.
		if (Wrong == MAX_WRONG)
		{
			cout << "\nYou've been hanged!";
		}
		// Infrom user that they won.
		else
		{
			cout << "\nYou guessed it!";
			cout << "\nThe word was " << Correct_Word << endl;
		}

		// Statement asking if user want's to play again (SPECIFICALLY WITH THE HANGMAN GAME).
		cout << "Would you like to play another round of hangman?: " << endl;
		SubScreenFormat();

		// Stating the words to type.
		cout << "[TYPE THE NUMBER]\n";
		cout << "\"1\"\n";
		cout << "\"2\"\n";
		SubScreenFormat();

		// Gather the results on whether the user typed 1 or 2.
		cout << "1: Yes" << endl;
		cout << "2: No" << endl;
		cout << ">";
		cin >> result;


		// The if else statement that will either make the program loop back or not.
		if (result == 1)
		{
			// The user has typed 1 which mean's the program will run again.
			PlayAgain = true;
		}
		else if (result == 2)
		{
			// The user has typed 2 which mean's the the program will not run again
			PlayAgain = false;
		}
		else
		{
			// The user typed something else besides 1 or 2. So the program will still not run again.
			PlayAgain = false;
		}

	}

	cout << "* The employee that asked you to play hangman tells you that he has a deck of cards. *\n";
	cout << "* He asks if you want to play BlackJack. *\n";
	cout << "* You think about it, you won't be bored but you could get in trouble for not working *\n";

	// User asked if they want to play Blackjack, collect user input.
	cout << "Would you like to play Blackjack?: " << endl;
	cin >> PlayBlackjack;

	// If user types yes then they will play Blackjack.
	if (PlayBlackjack == "yes")
	{
		ostream& operator<<(ostream& os, const Card& xCard);
		ostream& operator<<(ostream& os, const OtherPlayer& xOtherPlayer);


		// Black introduction.
		cout << "*** Welcome to the mini-game of Blackjack. ***\n";
		cout << "*** You will be handed out playing cards, and your goal is to reach a value of 21. ***\n";
		cout << "*** The winner can also be who ever is closest to 21. ***\n";
		cout << "*** If you go over 21 you will be bust which means you will automatically lose. ***\n";
		cout << "*** A hit means that you want another card to add up to your total. ***\n";
		cout << "*** You will indicate whether you want to hit by typing. ***\n";
		cout << "*** y for yes and n for no ***\n";
		cout << "*** A number will appear in parenthesis to display your hand value. ***\n";
		cout << "*** Good luck! ***\n";
		SubScreenFormat();

		// Number of players playing Blackjack.
		int numPlayers = 0;

		// The limit of how many can play is 7.
		while (numPlayers < 1 || numPlayers > 7)
		{
			cout << "* The employee that invited you to play Blackjack asks if you want invite any other employees. *\n";
			cout << "*** Press 1 if you just want to play Blackjack against the employee who invited you.  (solo)*** \n";
			cout << "*** Press any number higher than 1 for multiplayer. ***\n";

			// Ask the user how many other players he wants to play with.
			cout << "How many players? (1 - 7): ";
			cin >> numPlayers;
		}

		// Vector created for names.
		vector<string> names;
		string name;
		for (int i = 0; i < numPlayers; ++i)
		{
			// Ask player(s) for there gambling nickname.
			cout << "\n* The employee that asks you to play Blackjack asks you for your gambling nickname * \n";
			cout << "Enter your gambling nickname: ";
			cin >> name;
			names.push_back(name);
		}
		cout << endl;

		// Ask the user if they still want to play Blackjack.  
		BlackJack XBlackJack(names);
		char again = 'y';
		while (again != 'n' && again != 'N')
		{
			// If user types y then they will play Blackjack again.
			// If user types n then they will stop playing Blackjack.
			XBlackJack.Play();
			cout << "\nDo you want to play again? (Y/N): ";
			cin >> again;
		}

	}
}

// Function definition of display, specifically display(const vector<string>* const pInventory) *pointer*.
void Interactive::display(const std::vector<std::string>* const pInventory)
{
	// for loop for when string vector is equal to the inventory *pointer*.
	for (vector<string>::const_iterator iter = (*pInventory).begin();
		iter != (*pInventory).end(); ++iter)
	{
		// cout statement to print out the *pointer* iter.
		cout << *iter << endl;
	}
}

// Function definition of hackedTransaction.
void Interactive::hackedTransaction(int& x, int& y) // REFERENCES FOR INT X AND INT Y.
{
	int temp = x;
	x = y;
	y = temp;
}


Interactive::~Interactive()
{
}


Card::Card(CardValue CV, Suit S, bool IFU) : X_CardValue(CV), X_Suit(S), X_IsFaceUp(IFU)
{}

int Card::GetValue() const
{
	// If the card is "facing down" then it has a value of zero.
	int Value = 0;
	if (X_IsFaceUp)
	{
		// The value variable is now equal to the value correlated to the card.
		Value = X_CardValue;
		// The value of face cards (Jack, Queen, and King) equal 10.
		if (Value > 10)
		{
			Value = 10;
		}
	}
	return Value;
}

void Card::Flip()
{
	// Flip the card.
	X_IsFaceUp = !(X_IsFaceUp);
}

Hand::Hand()
{
	X_Cards.reserve(7);
}

Hand::~Hand()
{
	// Clear the card value from the hand.
	Clear();
}

void Hand::Add(Card* pCard)
{
	X_Cards.push_back(pCard);
}

void Hand::Clear()
{
	// Iterate throughout the vector which will free all the memory on the heap.
	vector<Card*>::iterator iter = X_Cards.begin();
	for (iter = X_Cards.begin(); iter != X_Cards.end(); ++iter)
	{
		delete *iter;
		*iter = 0;
	}

	// Clear out the vector from the pointers.
	X_Cards.clear();
}

int Hand::ValueTotal() const
{
	// If there is no card in the presence of the hand then return zero.
	if (X_Cards.empty())
	{
		return 0;
	}

	// If the first card has a value of zero then the card must be facing down.
	// Return zero.
	if (X_Cards[0]->GetValue() == 0)
	{
		return 0;
	}

	// Add up the total of the card values, the Ace is equal to one.
	int Total = 0;
	vector<Card*>::const_iterator iter;
	for (iter = X_Cards.begin(); iter != X_Cards.end(); ++iter)
	{
		Total += (*iter)->GetValue();
	}

	// Determine if the hand has an ace.
	bool ContainsAce = false;
	for (iter = X_Cards.begin(); iter != X_Cards.end(); ++iter)
	{
		if ((*iter)->GetValue() == Card::ACE)
		{
			ContainsAce = true;
		}
	}

	//if hand contains Ace and total is low enough, treat Ace as 11
	if (ContainsAce && Total <= 11)
	{
		// The total is added only 10 because the code should have already added 1 for the ace.
		Total += 10;
	}

	return Total;
}

OtherPlayer::OtherPlayer(const string& name) :
	X_Name(name)
{}

OtherPlayer::~OtherPlayer()
{}

bool OtherPlayer::IsBusted() const
{
	return (ValueTotal() > 21);
}

void OtherPlayer::Bust() const
{
	// Inform the user of the program that the other player has busted.
	cout << X_Name << " busts.\n";
}

Player::Player(const string& name) :
	OtherPlayer(name)
{}

Player::~Player()
{}

bool Player::IsHitting() const
{
	// Ask the player (program user) if they want a hit. 
	// Collects user input.
	cout << X_Name << ", do you want a hit? (Y/N): ";
	char response;
	cin >> response;
	return (response == 'y' || response == 'Y');
}

void Player::Win() const
{
	// Inform the player (program user) they have won.
	cout << X_Name << " wins.\n";
}

void Player::Lose() const
{
	// Inform the player (program user) they have lost.
	cout << X_Name << " loses.\n";
}

void Player::Push() const
{
	// Inform the player (program user) they have a push/tie.
	cout << X_Name << " pushes.\n";
}

House::House(const string& name) :
	OtherPlayer(name)
{}

House::~House()
{}

bool House::IsHitting() const
{
	// The house will always hit if they have a total value equal or less than 16.
	return (ValueTotal() <= 16);
}

void House::FlipFirstCard()
{
	// House will flip first card.
	if (!(X_Cards.empty()))
	{
		X_Cards[0]->Flip();
	}
	else
	{
		// Inform the player (program user) that the house has no card to flip.
		cout << "No card to flip!\n";
	}
}

Deck::Deck()
{
	// The amount of cards in the deck should be 52.
	// 52 cards in deck.
	X_Cards.reserve(52);
	AmountOfCards();
}

Deck::~Deck()
{}

void Deck::AmountOfCards()
{
	Clear();

	// Create the standard deck of 52 cards.
	for (int S = Card::CLUBS; S <= Card::SPADES; ++S)
	{
		for (int CV = Card::ACE; CV <= Card::KING; ++CV)
		{
			Add(new Card(static_cast<Card::CardValue>(CV),
				static_cast<Card::Suit>(S)));
		}
	}
}

void Deck::Shuffle()
{
	// Shuffle the cards.
	random_shuffle(X_Cards.begin(), X_Cards.end());
}

void Deck::Deal(Hand& xHand)
{
	// Deal out the cards.
	if (!X_Cards.empty())
	{
		xHand.Add(X_Cards.back());
		X_Cards.pop_back();
	}
	else
	{
		// Inform the player (program user) there are no cards available.
		cout << "Out of cards. Unable to deal.";
	}
}

void Deck::AdditionalCards(OtherPlayer& xOtherPlayer)
{
	cout << endl;

	// Continue to deal out cards unless the other player has busted.
	while (!(xOtherPlayer.IsBusted()) && xOtherPlayer.IsHitting())
	{
		Deal(xOtherPlayer);
		cout << xOtherPlayer << endl;

		if (xOtherPlayer.IsBusted())
		{
			xOtherPlayer.Bust();
		}
	}
}

BlackJack::BlackJack(const vector<string>& names)
{
	// Create the vector for players depending on the vector of names.     
	vector<string>::const_iterator pName;
	for (pName = names.begin(); pName != names.end(); ++pName)
	{
		X_Players.push_back(Player(*pName));
	}

	// Use random seed number generator.
	srand(static_cast<unsigned int>(time(0)));
	X_Deck.AmountOfCards();
	X_Deck.Shuffle();
}

BlackJack::~BlackJack()
{}

void  BlackJack::Play()
{
	// In the start of the card deal out 2 cards to everyone playing.
	vector<Player>::iterator pPlayer;
	for (int i = 0; i < 2; ++i)
	{
		for (pPlayer = X_Players.begin(); pPlayer != X_Players.end(); ++pPlayer)
		{
			X_Deck.Deal(*pPlayer);
		}
		X_Deck.Deal(X_House);
	}

	// The first card from the house is hidden.
	X_House.FlipFirstCard();

	// Display the hand of every player.
	for (pPlayer = X_Players.begin(); pPlayer != X_Players.end(); ++pPlayer)
	{
		cout << *pPlayer << endl;
	}
	cout << X_House << endl;

	// Deal additional cards to players.
	for (pPlayer = X_Players.begin(); pPlayer != X_Players.end(); ++pPlayer)
	{
		X_Deck.AdditionalCards(*pPlayer);
	}

	// The house will reveal their first card.
	X_House.FlipFirstCard();
	cout << endl << X_House;

	//  Deal additional card to the house.
	X_Deck.AdditionalCards(X_House);

	if (X_House.IsBusted())
	{
		// Everyone that continues playing wins.
		for (pPlayer = X_Players.begin(); pPlayer != X_Players.end(); ++pPlayer)
		{
			if (!(pPlayer->IsBusted()))
			{
				pPlayer->Win();
			}
		}
	}
	else
	{
		// Compare the value of each hand still playing to the value of the house's hand.
		for (pPlayer = X_Players.begin(); pPlayer != X_Players.end();
			++pPlayer)
		{
			if (!(pPlayer->IsBusted()))
			{
				if (pPlayer->ValueTotal() > X_House.ValueTotal())
				{
					pPlayer->Win();
				}
				else if (pPlayer->ValueTotal() < X_House.ValueTotal())
				{
					pPlayer->Lose();
				}
				else
				{
					pPlayer->Push();
				}
			}
		}

	}

	// Clear all the cards.
	for (pPlayer = X_Players.begin(); pPlayer != X_Players.end(); ++pPlayer)
	{
		pPlayer->Clear();
	}
	X_House.Clear();
}
